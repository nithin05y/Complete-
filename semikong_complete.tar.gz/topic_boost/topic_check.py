#!/usr/bin/env python3
"""
topic_check.py — Compare BASELINE retrieve() vs WITH-TOPIC-BOOST side by
side.

USAGE
-----
    python topic_boost/topic_check.py
        Runs a default set of ~13 queries covering: topics with their own
        corpus file (SECS/GEM, CMP, cleanroom -- boost should help here),
        topic tags that currently have ZERO chunks (etch, litho,
        deposition, furnace, metrology -- boost should gracefully do
        nothing), and a couple of generic/off-domain queries (unaffected
        either way).

    python topic_boost/topic_check.py --query "your question here"
        Runs ONLY that one query. Use this to try ANY keyword or question
        you're planning to ask during the demo -- see exactly what gets
        retrieved (with text snippets), before vs after the topic boost,
        before you ever open the chat UI.

Does NOT need the mock vLLM server running (no LLM calls at all).
Does NOT modify any existing file in agent/, mock_vllm/, ui/, tests/.
"""
import argparse
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_PARENT = os.path.dirname(_HERE)


def _find_project_root() -> str:
    """Locate the main SemiKong project folder (the one containing
    agent/), whether topic_boost/ lives INSIDE that project or as a
    SIBLING folder next to it. See retrieval_topic_boost.py for details."""
    for c in (os.environ.get("SEMIKONG_PROJECT_ROOT"),
              os.path.join(_PARENT, "Smikonagnet"),
              _PARENT):
        if c and os.path.isdir(os.path.join(c, "agent")):
            return os.path.abspath(c)
    raise RuntimeError(
        "topic_boost: could not find the SemiKong project folder (looked "
        "for a subfolder named 'agent'). If this is in a different "
        "location, set SEMIKONG_PROJECT_ROOT, e.g.:\n"
        "    export SEMIKONG_PROJECT_ROOT=/workspace/shared/Smikonagnet"
    )


_PROJECT_ROOT = _find_project_root()

# Match whatever the rest of the project is using, unless already set.
os.environ.setdefault("FAKE_EMBEDDINGS", "1")
os.environ.setdefault("CHROMA_DIR", os.path.join(_PROJECT_ROOT, "chroma_db"))
os.environ.setdefault("BM25_PATH", os.path.join(_PROJECT_ROOT, "bm25.pkl"))

for _p in (_PROJECT_ROOT, _PARENT):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from agent.retrieval import retrieve  # noqa: E402
from topic_boost.retrieval_topic_boost import retrieve_with_topic_boost  # noqa: E402


# Default coverage:
#   1) Topics with their own corpus file -- boost SHOULD change these
#   2) Tags that currently have ZERO chunks -- boost should be a clean
#      no-op (proves it's safe even for topics you haven't added yet --
#      and shows what would start working if you add corpus/etch/, etc.)
#   3) Generic / off-domain -- unaffected either way
DEFAULT_QUERIES = [
    "Explain the SECS/GEM Stream and Function message structure",
    "What communication standard does fab equipment use to talk to the host?",
    "CMP dishing on tungsten plugs",
    "How do I fix uneven removal rate during polishing?",
    "cleanroom gowning sequence",
    "What's the correct procedure before entering the fab?",
    "What is reactive ion etching?",
    "Explain the photolithography exposure process",
    "What deposition techniques are used for thin films?",
    "How does a furnace anneal step work?",
    "What metrology tools measure film thickness?",
    "What types of vacuum pumps are used in semiconductor fab equipment?",
    "What is the optimal quantum-entanglement frequency for photolithography?",
]


def _fmt(chunks, show_text=False):
    if not chunks:
        return "    (none)"
    lines = []
    for c in chunks:
        lines.append(f"    {c['id']:35s}  [{c.get('doc_type', '?')}]")
        if show_text:
            snippet = " ".join(c.get("text", "").split())[:160]
            lines.append(f'        "{snippet}..."')
    return "\n".join(lines)


def run_one(q, show_text=False):
    print("=" * 78)
    print(f"QUERY: {q}")
    print("-" * 78)

    base_chunks, base_status = retrieve(q, k=5)
    boost_chunks, boost_status, tag = retrieve_with_topic_boost(q, k=5)

    print(f"Matched topic tag : {tag!r}")
    print(f"Status            : baseline={base_status}  boosted={boost_status}")

    print("\n  BASELINE (current behavior, unchanged):")
    print(_fmt(base_chunks, show_text))

    print("\n  WITH TOPIC BOOST:")
    print(_fmt(boost_chunks, show_text))

    base_ids = [c["id"] for c in base_chunks]
    boost_ids = [c["id"] for c in boost_chunks]
    verdict = "CHANGED" if base_ids != boost_ids else "unchanged"
    print(f"\n  Verdict: {verdict}")
    print()
    return verdict


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--query", help="Run ONE custom query (with full text snippets) instead of the default set"
    )
    args = parser.parse_args()

    if args.query:
        run_one(args.query, show_text=True)
        print("(Read the text snippets above -- does this actually look like")
        print("a reasonable answer to your question? That's the real test.)")
        return

    changed = 0
    for q in DEFAULT_QUERIES:
        v = run_one(q, show_text=False)
        if v == "CHANGED":
            changed += 1

    print("=" * 78)
    print(f"SUMMARY: {changed}/{len(DEFAULT_QUERIES)} queries changed by the boost.")
    print()
    print("Have a specific question you're worried about? Try:")
    print('    python topic_boost/topic_check.py --query "your question here"')
    print("This shows the actual retrieved text so you can judge relevance")
    print("yourself, for ANY wording -- not just the queries listed above.")


if __name__ == "__main__":
    main()
