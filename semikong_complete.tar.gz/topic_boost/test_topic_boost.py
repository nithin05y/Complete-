"""
test_topic_boost.py — Unit tests for retrieval_topic_boost.py.

Run on its own (doesn't need the mock vLLM server):
    pytest topic_boost/test_topic_boost.py -v

Or alongside the main suite:
    pytest topic_boost/ -v
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_PARENT = os.path.dirname(_HERE)


def _find_project_root() -> str:
    """See retrieval_topic_boost.py for details."""
    for c in (os.environ.get("SEMIKONG_PROJECT_ROOT"),
              os.path.join(_PARENT, "Smikonagnet"),
              _PARENT):
        if c and os.path.isdir(os.path.join(c, "agent")):
            return os.path.abspath(c)
    raise RuntimeError(
        "topic_boost: could not find the SemiKong project folder. Set "
        "SEMIKONG_PROJECT_ROOT to its full path."
    )


_PROJECT_ROOT = _find_project_root()

os.environ.setdefault("FAKE_EMBEDDINGS", "1")
os.environ.setdefault("CHROMA_DIR", os.path.join(_PROJECT_ROOT, "chroma_db"))
os.environ.setdefault("BM25_PATH", os.path.join(_PROJECT_ROOT, "bm25.pkl"))

for _p in (_PROJECT_ROOT, _PARENT):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from agent import retrieval as R  # noqa: E402
from topic_boost import retrieval_topic_boost as TB  # noqa: E402


# ── match_tag ────────────────────────────────────────────────────────────────

def test_match_tag_secs_gem():
    assert TB.match_tag("Explain the SECS/GEM Stream and Function message structure") == "SECS_GEM"


def test_match_tag_cmp():
    assert TB.match_tag("CMP dishing on tungsten plugs") == "CMP"


def test_match_tag_cleanroom():
    assert TB.match_tag("cleanroom gowning sequence") == "CLEANROOM"


def test_match_tag_none_for_unrelated_query():
    assert TB.match_tag("what time is it") is None


# ── retrieve_with_topic_boost: passthrough cases ───────────────────────────────

def test_passthrough_when_no_tag_matches():
    """No topic keyword in the query -> result identical to baseline,
    tag reported as None."""
    query = "what time is it"
    base_chunks, base_status = R.retrieve(query, k=5)
    boost_chunks, boost_status, tag = TB.retrieve_with_topic_boost(query, k=5)

    assert tag is None
    assert boost_status == base_status
    assert [c["id"] for c in boost_chunks] == [c["id"] for c in base_chunks]


def test_passthrough_when_status_not_ok(monkeypatch):
    """If the underlying retrieve() abstains/errors, topic_boost must
    return that result completely unchanged -- never override abstain."""
    monkeypatch.setattr(TB.R, "retrieve", lambda query, k=5: ([], "no_relevant_context"))

    chunks, status, tag = TB.retrieve_with_topic_boost(
        "Explain the SECS/GEM Stream and Function message structure", k=5
    )
    assert chunks == []
    assert status == "no_relevant_context"
    assert tag is None


def test_tag_with_zero_chunks_is_noop(monkeypatch):
    """Query matches a tag's keywords, but that tag has zero chunks in
    this corpus -> result == baseline exactly, tag reported as None."""
    fake_baseline = [{"id": "x", "text": "...", "source_file": "x", "doc_type": "MISC"}]
    monkeypatch.setattr(TB.R, "retrieve", lambda query, k=5: (fake_baseline, "ok"))

    # "lithography" matches LITHO keywords, but no LITHO-tagged chunks
    # exist in this corpus.
    chunks, status, tag = TB.retrieve_with_topic_boost(
        "What is the photolithography exposure process?", k=5
    )
    assert tag is None
    assert chunks == fake_baseline


# ── retrieve_with_topic_boost: the actual bug scenario ─────────────────────────

def test_rescues_buried_tag(monkeypatch):
    """
    THE KEY TEST -- reproduces the reported bug:

    On the 7663-chunk corpus, asking about "SECS/GEM Stream and Function"
    returned 5 chunks, NONE of them from secs_gem_overview.txt -- even
    though that file's chunks ARE in the corpus (just out-ranked by the
    much larger textbook in the hybrid RRF merge).

    Here we simulate exactly that: monkeypatch retrieve() to return a
    baseline with ZERO SECS_GEM chunks (using real non-SECS_GEM chunks
    from this corpus), while the real _bm25 index (loaded normally)
    still contains the 5 real SECS_GEM chunks. topic_boost must inject
    some of them anyway.
    """
    R._load()  # ensure real singletons are populated
    all_chunks = R._bm25["chunks"]

    non_secs_gem = [c for c in all_chunks if c["doc_type"] != "SECS_GEM"]
    secs_gem_ids = {c["id"] for c in all_chunks if c["doc_type"] == "SECS_GEM"}

    assert secs_gem_ids, "test corpus must contain SECS_GEM chunks"
    assert len(non_secs_gem) >= 5

    buried_baseline = non_secs_gem[:5]
    assert not (set(c["id"] for c in buried_baseline) & secs_gem_ids)

    monkeypatch.setattr(TB.R, "retrieve", lambda query, k=5: (buried_baseline, "ok"))

    chunks, status, tag = TB.retrieve_with_topic_boost(
        "Explain the SECS/GEM Stream and Function message structure", k=5
    )

    assert status == "ok"
    assert tag == "SECS_GEM"

    result_ids = {c["id"] for c in chunks}
    rescued = result_ids & secs_gem_ids
    assert rescued, (
        f"Expected at least one SECS_GEM chunk to be rescued into the "
        f"result, got chunks: {sorted(result_ids)}"
    )
    assert len(chunks) <= 5


def test_boost_slots_configurable(monkeypatch):
    """boost_slots controls how many tag-matched chunks are guaranteed."""
    R._load()
    all_chunks = R._bm25["chunks"]
    non_secs_gem = [c for c in all_chunks if c["doc_type"] != "SECS_GEM"]
    secs_gem_ids = {c["id"] for c in all_chunks if c["doc_type"] == "SECS_GEM"}

    monkeypatch.setattr(TB.R, "retrieve", lambda query, k=5: (non_secs_gem[:5], "ok"))

    chunks, _, _ = TB.retrieve_with_topic_boost(
        "Explain the SECS/GEM Stream and Function message structure",
        k=5, boost_slots=1,
    )
    rescued = {c["id"] for c in chunks} & secs_gem_ids
    assert len(rescued) == 1


# ── output shape ─────────────────────────────────────────────────────────────

def test_result_chunks_have_expected_keys():
    chunks, status, _ = TB.retrieve_with_topic_boost("CMP dishing on tungsten plugs", k=5)
    assert status == "ok"
    for c in chunks:
        assert set(c.keys()) >= {"id", "text", "source_file", "doc_type"}


def test_result_never_exceeds_k():
    for k in (1, 3, 5):
        chunks, status, _ = TB.retrieve_with_topic_boost(
            "Explain the SECS/GEM Stream and Function message structure", k=k
        )
        if status == "ok":
            assert len(chunks) <= k
