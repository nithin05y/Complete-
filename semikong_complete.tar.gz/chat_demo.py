#!/usr/bin/env python3
"""
chat_demo.py — Multi-turn conversational demo for the v3 chat agent.

Runs two scripted conversations against the (already-running) mock vLLM
server:

  SEQUENCE A — §13 smoke test: hello -> vague problem -> tool ID + symptom
               -> one-word "radial" follow-up (THE KEY TEST: TS-05)

  SEQUENCE B — DEMO-1 exact wording: "I have a problem with CMP" -> clarify
               -> "EQ-CMP-03, removal rate is uneven" -> guided diagnosis
               -> "Radial" -> rewritten query + final diagnosis

Also exercises escalation (TS-15) and off-domain abstention (TS-11).

Prerequisites: same as demo.py — corpus ingested, mock vLLM server running
on :8000 (both handled automatically by run_demo.sh).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from agent.chat_agent import Conversation, handle_turn, is_abstained  # noqa: E402
from agent.retrieval import retrieve as _base_retrieve  # noqa: E402
from agent.critic import verify_answer  # noqa: E402

# Use topic_boost's tag-aware retrieval if present; otherwise fall back to
# plain retrieve(), unchanged. See ui/gradio_app.py for more comments.
try:
    from topic_boost.retrieval_topic_boost import retrieve_with_topic_boost

    def retrieve(query, k=5):
        chunks, status, _tag = retrieve_with_topic_boost(query, k=k)
        return chunks, status
except ImportError:
    retrieve = _base_retrieve


def run_turn(convo, msg, label):
    reply, trace = handle_turn(convo, msg, retrieve, verify_answer)
    print(f"\n{'-'*74}\n{label}")
    print(f"  Operator: {msg!r}")
    print(f"  Intent:   {trace['intent']}")
    plan = trace.get("plan") or {}
    if plan.get("rationale"):
        print(f"  Planner rationale: {plan['rationale']}")
    if plan.get("standalone_query") and plan["standalone_query"] != msg:
        print(f"  Rewritten query:   {plan['standalone_query']!r}")
    print(f"  Agent: {reply}")
    return reply, trace


def main():
    print("=" * 74)
    print("  SemiKong Chat Agent — Conversational Demo")
    print("=" * 74)

    failures = []

    # ── Sequence A ────────────────────────────────────────────────────────
    print("\n" + "#" * 74)
    print("# SEQUENCE A — multi-turn, ending with THE KEY TEST (TS-05)")
    print("#" * 74)

    c = Conversation()
    run_turn(c, "hello", "Turn 1 — greeting")
    run_turn(c, "I have a problem", "Turn 2 — vague (expect clarify)")
    run_turn(c, "EQ-CMP-03, removal rate is uneven", "Turn 3 — tool ID + symptom")
    _, t4 = run_turn(c, "radial", "Turn 4 — one-word follow-up (THE KEY TEST)")

    sq = (t4.get("plan") or {}).get("standalone_query") or ""
    if "EQ-CMP-03" in sq and "radial" in sq.lower():
        print(f"\n  *** PASS: 'radial' was rewritten to {sq!r}, using the tool "
              f"ID from turn 3. This is conversational memory at work. ***")
    else:
        failures.append("TS-05: 'radial' follow-up was not rewritten using prior context")
        print(f"\n  *** FAIL: standalone_query was {sq!r} -- expected it to "
              f"contain 'EQ-CMP-03' and 'radial' ***")

    # ── Sequence B ────────────────────────────────────────────────────────
    print("\n\n" + "#" * 74)
    print("# SEQUENCE B — DEMO-1 (three-turn guided diagnosis)")
    print("#" * 74)

    c2 = Conversation()
    _, tA = run_turn(c2, "I have a problem with CMP", "Turn A")
    if tA["intent"] != "clarify":
        failures.append("DEMO-1 Turn A: expected clarify intent")

    run_turn(c2, "EQ-CMP-03, removal rate is uneven", "Turn B")
    _, tC = run_turn(c2, "Radial", "Turn C — one-word follow-up (capital R)")

    sq = (tC.get("plan") or {}).get("standalone_query") or ""
    if not ("EQ-CMP-03" in sq and "radial" in sq.lower()):
        failures.append("DEMO-1 Turn C: 'Radial' was not rewritten using prior context")

    # ── Sequence C — escalation + off-domain abstention ─────────────────────
    print("\n\n" + "#" * 74)
    print("# SEQUENCE C — escalation (TS-15) and off-domain abstention (TS-11)")
    print("#" * 74)

    c3 = Conversation()
    _, t = run_turn(c3, "I need a human now, this is dangerous", "Escalation")
    if t["intent"] != "escalate" or not c3.escalated:
        failures.append("TS-15: escalation intent/flag not set")

    c4 = Conversation()
    _, t = run_turn(c4, "What's the recommended bake temperature for sourdough?",
                    "Off-domain (expect abstain)")
    if not is_abstained(t):
        failures.append("TS-11: off-domain question did not abstain")

    # ── Summary ──────────────────────────────────────────────────────────
    print("\n\n" + "=" * 74)
    if failures:
        print("  CHAT DEMO: FAILURES DETECTED")
        for f in failures:
            print(f"   - {f}")
        print("=" * 74)
        sys.exit(1)
    else:
        print("  CHAT DEMO: ALL SCENARIOS PASSED")
        print("=" * 74)


if __name__ == "__main__":
    main()
