"""
tests/test_chat_agent.py
========================
Tests for agent/chat_agent.py — the v3 multi-turn conversational core.

Covers: Conversation (sliding window, history formatting), plan() (intent
classification + JSON-fallback safety), generate() (source-ID validation,
abstain paths), _render_reply() (citation rendering), and handle_turn()
(all four intents, error-handling for every stage).

THE KEY TEST (TestRadialFollowUpRewrite) verifies the conversational-memory
behaviour that distinguishes a chatbot from single-shot search: a one-word
follow-up like "radial" must be rewritten by the planner into a standalone
query using context from earlier turns, and handle_turn() must retrieve
using THAT rewritten query, not the raw one-word message.

No vLLM, no ChromaDB, no GPU required — everything is mocked.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from unittest.mock import patch, MagicMock

from agent.chat_agent import (
    Turn, Conversation, plan, generate, _render_reply, handle_turn,
    is_abstained, PLANNER_SYS, GEN_SYS,
)


def _llm_returning(content: str):
    """Build a MagicMock LLM whose .invoke(...).content == content."""
    llm = MagicMock()
    llm.invoke.return_value = MagicMock(content=content)
    return llm


# ════════════════════════════════════════════════════════════════════════════
class TestConversation:

    def test_empty_history_text(self):
        c = Conversation()
        assert c.history_text() == ""

    def test_add_and_history_text_formatting(self):
        c = Conversation()
        c.add("operator", "hello")
        c.add("agent", "hi there")
        assert c.history_text() == "OPERATOR: hello\nAGENT: hi there"

    def test_history_text_respects_n(self):
        c = Conversation()
        for i in range(5):
            c.add("operator", f"msg{i}")
        # last 2 only
        assert c.history_text(n=2) == "OPERATOR: msg3\nOPERATOR: msg4"

    def test_sliding_window_max_turns(self):
        c = Conversation(max_turns=3)
        for i in range(5):
            c.add("operator", f"msg{i}")
        assert len(c.turns) == 3
        assert [t.content for t in c.turns] == ["msg2", "msg3", "msg4"]

    def test_escalated_defaults_false(self):
        c = Conversation()
        assert c.escalated is False

    def test_metadata_defaults_to_empty_dict_per_turn(self):
        c = Conversation()
        c.add("operator", "a")
        c.add("operator", "b", {"foo": "bar"})
        assert c.turns[0].metadata == {}
        assert c.turns[1].metadata == {"foo": "bar"}
        # mutating one turn's metadata must not affect another's
        c.turns[0].metadata["x"] = 1
        assert c.turns[1].metadata == {"foo": "bar"}


# ════════════════════════════════════════════════════════════════════════════
class TestPlan:

    def test_valid_smalltalk_json(self):
        c = Conversation()
        c.add("operator", "hello")
        raw = json.dumps({"intent": "smalltalk", "standalone_query": None,
                           "clarifying_question": None, "rationale": "greeting"})
        with patch("agent.chat_agent._get_llm", return_value=_llm_returning(raw)):
            result = plan(c)
        assert result["intent"] == "smalltalk"

    def test_valid_retrieve_with_standalone_query(self):
        c = Conversation()
        c.add("operator", "EQ-CMP-03, removal rate is uneven")
        raw = json.dumps({"intent": "retrieve",
                           "standalone_query": "EQ-CMP-03 removal rate uneven",
                           "clarifying_question": None, "rationale": "technical"})
        with patch("agent.chat_agent._get_llm", return_value=_llm_returning(raw)):
            result = plan(c)
        assert result["intent"] == "retrieve"
        assert result["standalone_query"] == "EQ-CMP-03 removal rate uneven"

    def test_invalid_json_falls_back_to_retrieve_with_last_message(self):
        c = Conversation()
        c.add("operator", "some message")
        with patch("agent.chat_agent._get_llm", return_value=_llm_returning("not json at all")):
            result = plan(c)
        assert result["intent"] == "retrieve"
        assert result["standalone_query"] == "some message"
        assert result["rationale"] == "json_parse_fallback"

    def test_json_missing_intent_key_falls_back(self):
        c = Conversation()
        c.add("operator", "foo")
        raw = json.dumps({"some_other_key": "value"})
        with patch("agent.chat_agent._get_llm", return_value=_llm_returning(raw)):
            result = plan(c)
        assert result["intent"] == "retrieve"
        assert result["standalone_query"] == "foo"

    def test_invalid_intent_value_falls_back(self):
        c = Conversation()
        c.add("operator", "bar")
        raw = json.dumps({"intent": "banana", "standalone_query": "x",
                           "clarifying_question": None, "rationale": "r"})
        with patch("agent.chat_agent._get_llm", return_value=_llm_returning(raw)):
            result = plan(c)
        assert result["intent"] == "retrieve"
        assert result["standalone_query"] == "bar"

    def test_llm_exception_falls_back_to_retrieve(self):
        c = Conversation()
        c.add("operator", "EQ-ETCH-02 plasma fault")
        bad_llm = MagicMock()
        bad_llm.invoke.side_effect = ConnectionError("boom")
        with patch("agent.chat_agent._get_llm", return_value=bad_llm):
            result = plan(c)
        assert result["intent"] == "retrieve"
        assert result["standalone_query"] == "EQ-ETCH-02 plasma fault"
        assert "llm_error" in result["rationale"]

    def test_retrieve_without_standalone_query_uses_last_message(self):
        """If the planner says retrieve but forgets standalone_query, use
        the operator's raw message rather than leaving it null."""
        c = Conversation()
        c.add("operator", "EQ-CMP-03 alarm 4012")
        raw = json.dumps({"intent": "retrieve", "standalone_query": None,
                           "clarifying_question": None, "rationale": "r"})
        with patch("agent.chat_agent._get_llm", return_value=_llm_returning(raw)):
            result = plan(c)
        assert result["standalone_query"] == "EQ-CMP-03 alarm 4012"

    def test_empty_conversation_does_not_crash(self):
        c = Conversation()
        raw = json.dumps({"intent": "retrieve", "standalone_query": None,
                           "clarifying_question": None, "rationale": "r"})
        with patch("agent.chat_agent._get_llm", return_value=_llm_returning(raw)):
            result = plan(c)
        assert result["standalone_query"] == ""

    def test_planner_system_prompt_is_well_formed(self):
        """Sanity: the planner prompt mentions all four intents."""
        for intent in ("smalltalk", "clarify", "retrieve", "escalate"):
            assert intent in PLANNER_SYS


# ════════════════════════════════════════════════════════════════════════════
class TestGenerate:

    SAMPLE_CHUNKS = [
        {"id": "cmp_primer_c0005", "text": "Uneven CMP removal across the wafer..."},
        {"id": "cmp_primer_c0008", "text": "Check the pad-conditioner diamond-disk wear..."},
    ]

    def test_empty_chunks_abstains_without_llm_call(self):
        c = Conversation()
        with patch("agent.chat_agent._get_llm") as mock_get_llm:
            result = generate(c, [])
        mock_get_llm.assert_not_called()
        assert result["abstained"] is True
        assert result["claims"] == []

    def test_valid_claims_with_source_ids(self):
        c = Conversation()
        c.add("operator", "EQ-CMP-03 removal uneven")
        raw = json.dumps({
            "abstained": False, "abstain_reason": None,
            "claims": [{"text": "Pad-conditioner wear is a common cause.",
                        "source_ids": ["cmp_primer_c0005"]}],
            "follow_up_question": "center-to-edge or radial?",
            "suggested_action": None,
        })
        with patch("agent.chat_agent._get_llm", return_value=_llm_returning(raw)):
            result = generate(c, self.SAMPLE_CHUNKS)
        assert result["abstained"] is False
        assert len(result["claims"]) == 1
        assert result["claims"][0]["source_ids"] == ["cmp_primer_c0005"]
        assert result["follow_up_question"] == "center-to-edge or radial?"

    def test_strips_hallucinated_source_ids(self):
        c = Conversation()
        raw = json.dumps({
            "abstained": False, "abstain_reason": None,
            "claims": [{"text": "Mixed sources.",
                        "source_ids": ["cmp_primer_c0005", "made_up_id_c9999"]}],
            "follow_up_question": None, "suggested_action": None,
        })
        with patch("agent.chat_agent._get_llm", return_value=_llm_returning(raw)):
            result = generate(c, self.SAMPLE_CHUNKS)
        assert result["claims"][0]["source_ids"] == ["cmp_primer_c0005"]

    def test_all_claims_invalid_sources_triggers_abstain(self):
        c = Conversation()
        raw = json.dumps({
            "abstained": False, "abstain_reason": None,
            "claims": [{"text": "Bad claim.", "source_ids": ["nonexistent_c0000"]}],
            "follow_up_question": None, "suggested_action": None,
        })
        with patch("agent.chat_agent._get_llm", return_value=_llm_returning(raw)):
            result = generate(c, self.SAMPLE_CHUNKS)
        assert result["abstained"] is True
        assert result["claims"] == []

    def test_llm_exception_returns_abstain(self):
        c = Conversation()
        bad_llm = MagicMock()
        bad_llm.invoke.side_effect = TimeoutError("slow")
        with patch("agent.chat_agent._get_llm", return_value=bad_llm):
            result = generate(c, self.SAMPLE_CHUNKS)
        assert result["abstained"] is True
        assert "LLM call failed" in result["abstain_reason"]
        assert result["suggested_action"] == "Check vLLM server."

    def test_invalid_json_returns_abstain(self):
        c = Conversation()
        with patch("agent.chat_agent._get_llm", return_value=_llm_returning("garbage")):
            result = generate(c, self.SAMPLE_CHUNKS)
        assert result["abstained"] is True
        assert result["claims"] == []

    def test_missing_optional_fields_get_defaults(self):
        """Generator returns only the required minimum -- defaults fill in."""
        c = Conversation()
        raw = json.dumps({
            "abstained": False,
            "claims": [{"text": "ok", "source_ids": ["cmp_primer_c0005"]}],
        })
        with patch("agent.chat_agent._get_llm", return_value=_llm_returning(raw)):
            result = generate(c, self.SAMPLE_CHUNKS)
        assert result["follow_up_question"] is None
        assert result["suggested_action"] is None
        assert result["abstain_reason"] is None

    def test_generator_system_prompt_mentions_follow_up(self):
        """Sanity: this is the marker the mock server uses to distinguish
        v3 conversational calls from v2 single-shot calls."""
        assert "follow_up_question" in GEN_SYS


# ════════════════════════════════════════════════════════════════════════════
class TestRenderReply:

    def test_abstained_returns_reason(self):
        out = _render_reply({"abstained": True, "abstain_reason": "No source."})
        assert out == "No source."

    def test_abstained_without_reason_has_safe_default(self):
        out = _render_reply({"abstained": True, "abstain_reason": None})
        assert "escalat" in out.lower()

    def test_single_claim_citation_marker(self):
        verified = {"abstained": False,
                     "claims": [{"text": "Claim A.", "source_ids": ["c1"]}]}
        out = _render_reply(verified)
        assert out == "Claim A. [1]"

    def test_repeated_source_reuses_same_marker(self):
        verified = {"abstained": False, "claims": [
            {"text": "Claim A.", "source_ids": ["c1"]},
            {"text": "Claim B.", "source_ids": ["c2"]},
            {"text": "Claim C.", "source_ids": ["c1"]},
        ]}
        out = _render_reply(verified)
        # c1 -> [1] both times, c2 -> [2]
        assert "Claim A. [1]" in out
        assert "Claim B. [2]" in out
        assert "Claim C. [1]" in out

    def test_multi_source_claim_gets_multiple_markers(self):
        verified = {"abstained": False, "claims": [
            {"text": "Claim A.", "source_ids": ["c1", "c2"]},
        ]}
        out = _render_reply(verified)
        assert out == "Claim A. [1][2]"

    def test_follow_up_and_suggested_action_appended(self):
        verified = {"abstained": False,
                     "claims": [{"text": "Claim.", "source_ids": ["c1"]}],
                     "follow_up_question": "Center or radial?",
                     "suggested_action": "Check the disk."}
        out = _render_reply(verified)
        assert "Follow-up: Center or radial?" in out
        assert "Suggested action: Check the disk." in out


# ════════════════════════════════════════════════════════════════════════════
class TestHandleTurn:
    """All four intents, plus error-handling for every stage."""

    def _planned(self, intent, **kw):
        base = {"intent": intent, "standalone_query": None,
                "clarifying_question": None, "rationale": "test"}
        base.update(kw)
        return base

    def test_smalltalk_intent(self):
        c = Conversation()
        with patch("agent.chat_agent.plan", return_value=self._planned("smalltalk")):
            reply, trace = handle_turn(c, "hello", MagicMock(), MagicMock())
        assert trace["intent"] == "smalltalk"
        assert "troubleshooting" in reply.lower()
        # operator + agent turns recorded
        assert len(c.turns) == 2
        assert c.turns[0].role == "operator"
        assert c.turns[1].role == "agent"

    def test_clarify_intent_with_question(self):
        c = Conversation()
        p = self._planned("clarify", clarifying_question="Which tool ID?")
        with patch("agent.chat_agent.plan", return_value=p):
            reply, trace = handle_turn(c, "I have a problem", MagicMock(), MagicMock())
        assert trace["intent"] == "clarify"
        assert reply == "Which tool ID?"

    def test_clarify_intent_default_question_when_missing(self):
        c = Conversation()
        p = self._planned("clarify", clarifying_question=None)
        with patch("agent.chat_agent.plan", return_value=p):
            reply, trace = handle_turn(c, "I have a problem", MagicMock(), MagicMock())
        assert "tool" in reply.lower() and "symptom" in reply.lower()

    def test_escalate_sets_flag_and_replies(self):
        c = Conversation()
        with patch("agent.chat_agent.plan", return_value=self._planned("escalate")):
            reply, trace = handle_turn(c, "I need a human now", MagicMock(), MagicMock())
        assert trace["intent"] == "escalate"
        assert c.escalated is True
        assert "escalat" in reply.lower()

    def test_retrieve_no_relevant_context_abstains_gracefully(self):
        c = Conversation()
        p = self._planned("retrieve", standalone_query="sourdough bread")
        retrieve_fn = MagicMock(return_value=([], "no_relevant_context"))
        with patch("agent.chat_agent.plan", return_value=p):
            reply, trace = handle_turn(c, "sourdough?", retrieve_fn, MagicMock())
        assert trace["abstained"] is True
        assert "reliable source" in reply.lower()
        retrieve_fn.assert_called_once_with("sourdough bread", k=5)

    def test_retrieve_happy_path_renders_citations(self):
        c = Conversation()
        p = self._planned("retrieve", standalone_query="EQ-CMP-03 removal uneven")
        chunks = [{"id": "c1", "text": "chunk text"}]
        retrieve_fn = MagicMock(return_value=(chunks, "ok"))
        verified = {"abstained": False,
                     "claims": [{"text": "Pad wear.", "source_ids": ["c1"]}],
                     "follow_up_question": "radial?", "suggested_action": None}
        verify_fn = MagicMock(return_value=verified)

        with patch("agent.chat_agent.plan", return_value=p), \
             patch("agent.chat_agent.generate", return_value={"raw": "unused"}):
            reply, trace = handle_turn(c, "EQ-CMP-03, removal rate is uneven",
                                       retrieve_fn, verify_fn)

        assert "Pad wear. [1]" in reply
        assert "Follow-up: radial?" in reply
        assert trace["verified"] == verified
        assert trace["chunks"] == chunks

    def test_retrieve_abstained_after_verify(self):
        c = Conversation()
        p = self._planned("retrieve", standalone_query="q")
        chunks = [{"id": "c1", "text": "t"}]
        retrieve_fn = MagicMock(return_value=(chunks, "ok"))
        verified = {"abstained": True, "abstain_reason": "All claims failed critic verification.",
                     "claims": [], "stripped_count": 1}
        verify_fn = MagicMock(return_value=verified)

        with patch("agent.chat_agent.plan", return_value=p), \
             patch("agent.chat_agent.generate", return_value={"unused": True}):
            reply, trace = handle_turn(c, "msg", retrieve_fn, verify_fn)

        assert reply == "All claims failed critic verification."
        assert trace["verified"]["stripped_count"] == 1

    # ── error handling ───────────────────────────────────────────────────

    def test_plan_exception_falls_back_to_retrieve(self):
        c = Conversation()
        retrieve_fn = MagicMock(return_value=([], "no_relevant_context"))
        with patch("agent.chat_agent.plan", side_effect=RuntimeError("planner down")):
            reply, trace = handle_turn(c, "anything", retrieve_fn, MagicMock())
        assert trace["intent"] == "retrieve"
        retrieve_fn.assert_called_once_with("anything", k=5)

    def test_retrieve_fn_exception_handled_gracefully(self):
        c = Conversation()
        p = self._planned("retrieve", standalone_query="q")
        retrieve_fn = MagicMock(side_effect=ConnectionError("chroma down"))
        with patch("agent.chat_agent.plan", return_value=p):
            reply, trace = handle_turn(c, "msg", retrieve_fn, MagicMock())
        assert trace["abstained"] is True
        assert "reliable source" in reply.lower()

    def test_generate_exception_handled_gracefully(self):
        c = Conversation()
        p = self._planned("retrieve", standalone_query="q")
        chunks = [{"id": "c1", "text": "t"}]
        retrieve_fn = MagicMock(return_value=(chunks, "ok"))
        verify_fn = MagicMock(side_effect=lambda raw, by_id: raw)  # passthrough

        with patch("agent.chat_agent.plan", return_value=p), \
             patch("agent.chat_agent.generate", side_effect=RuntimeError("gen exploded")):
            reply, trace = handle_turn(c, "msg", retrieve_fn, verify_fn)

        assert trace["verified"]["abstained"] is True
        assert "Generator error" in trace["verified"]["abstain_reason"]

    def test_verify_fn_exception_handled_gracefully(self):
        c = Conversation()
        p = self._planned("retrieve", standalone_query="q")
        chunks = [{"id": "c1", "text": "t"}]
        retrieve_fn = MagicMock(return_value=(chunks, "ok"))
        raw = {"abstained": False, "claims": [{"text": "x", "source_ids": ["c1"]}],
               "follow_up_question": None, "suggested_action": None}
        verify_fn = MagicMock(side_effect=RuntimeError("critic down"))

        with patch("agent.chat_agent.plan", return_value=p), \
             patch("agent.chat_agent.generate", return_value=raw):
            reply, trace = handle_turn(c, "msg", retrieve_fn, verify_fn)

        # falls back to rendering the unverified raw answer rather than crashing
        assert "x [1]" in reply
        assert "critic_error" in trace["verified"]

    def test_unknown_intent_value_defaults_to_retrieve(self):
        c = Conversation()
        p = self._planned("does_not_exist", standalone_query="q")
        retrieve_fn = MagicMock(return_value=([], "no_relevant_context"))
        with patch("agent.chat_agent.plan", return_value=p):
            reply, trace = handle_turn(c, "msg", retrieve_fn, MagicMock())
        assert trace["intent"] == "retrieve"
        retrieve_fn.assert_called_once()

    def test_conversation_records_both_turns_on_retrieve_path(self):
        c = Conversation()
        p = self._planned("retrieve", standalone_query="q")
        chunks = [{"id": "c1", "text": "t"}]
        retrieve_fn = MagicMock(return_value=(chunks, "ok"))
        verified = {"abstained": False, "claims": [{"text": "x", "source_ids": ["c1"]}],
                     "follow_up_question": None, "suggested_action": None}
        verify_fn = MagicMock(return_value=verified)

        with patch("agent.chat_agent.plan", return_value=p), \
             patch("agent.chat_agent.generate", return_value={"unused": True}):
            handle_turn(c, "msg", retrieve_fn, verify_fn)

        assert len(c.turns) == 2
        assert c.turns[0].role == "operator" and c.turns[0].content == "msg"
        assert c.turns[1].role == "agent"
        assert c.turns[1].metadata["chunks_used"] == ["c1"]


# ════════════════════════════════════════════════════════════════════════════
class TestIsAbstained:
    """
    is_abstained() must recognize an abstain regardless of WHICH layer
    caught it -- this is the bug that surfaced on a large real corpus:
    retrieval no longer says 'below threshold' for an off-domain query
    once there are thousands of chunks (something always scores within
    range), but the generator's own off-domain check still abstains.
    chat_demo.py's TS-11 check used to look only at trace["abstained"]
    (shape 1) and missed shape 2 -- a false failure on a working system.
    """

    def test_shape1_retrieval_level_abstain(self):
        trace = {"intent": "retrieve", "plan": {}, "abstained": True,
                 "query": "q", "chunks": []}
        assert is_abstained(trace) is True

    def test_shape2_generator_level_abstain(self):
        """retrieval succeeded (status=ok, real chunks) but the generator
        recognized the query as off-domain and abstained -- no top-level
        'abstained' key, it's nested under 'verified'."""
        trace = {"intent": "retrieve", "plan": {}, "query": "q",
                 "chunks": [{"id": "c1", "text": "..."}],
                 "verified": {"abstained": True,
                               "abstain_reason": "No reliable source in knowledge base for this query.",
                               "claims": [], "stripped_count": 0}}
        assert is_abstained(trace) is True

    def test_happy_path_not_abstained(self):
        trace = {"intent": "retrieve", "plan": {}, "query": "q",
                 "chunks": [{"id": "c1", "text": "..."}],
                 "verified": {"abstained": False,
                               "claims": [{"text": "x", "source_ids": ["c1"]}],
                               "stripped_count": 0}}
        assert is_abstained(trace) is False

    def test_non_retrieve_intents_not_abstained(self):
        for intent in ("smalltalk", "clarify", "escalate"):
            assert is_abstained({"intent": intent, "plan": {}}) is False

    def test_end_to_end_off_domain_with_large_corpus_shape(self):
        """Full handle_turn(): retrieval returns status='ok' with real
        chunks (as it would on a 7000+ chunk corpus), but the generator
        abstains because the query is off-domain. is_abstained() must
        catch this even though there's no top-level 'abstained' key."""
        c = Conversation()
        p = {"intent": "retrieve", "standalone_query": "sourdough bread temperature",
             "clarifying_question": None, "rationale": "technical query, retrieving directly"}
        chunks = [{"id": "fundamentals_c1231", "text": "unrelated fab content..."}]
        retrieve_fn = MagicMock(return_value=(chunks, "ok"))

        gen_result = {"abstained": True,
                       "abstain_reason": "No reliable source in knowledge base for this query.",
                       "claims": [], "follow_up_question": None,
                       "suggested_action": "Escalate to on-call process engineer."}

        def fake_verify(raw, chunks_by_id):
            out = dict(raw)
            out["stripped_count"] = 0
            return out

        with patch("agent.chat_agent.plan", return_value=p), \
             patch("agent.chat_agent.generate", return_value=gen_result):
            reply, trace = handle_turn(c, "sourdough?", retrieve_fn, fake_verify)

        assert "abstained" not in trace          # shape 2, not shape 1
        assert is_abstained(trace) is True
        assert reply == "No reliable source in knowledge base for this query."


# ════════════════════════════════════════════════════════════════════════════
class TestRadialFollowUpRewrite:
    """
    THE KEY TEST — TS-05.

    "radial" as a one-word follow-up after a CMP/tool-ID turn must be
    rewritten by the planner into a standalone query that retains the tool
    ID and topic from the prior turn. handle_turn() must call retrieve_fn
    with THAT rewritten query, not the literal one-word message.
    """

    def test_radial_rewrite_used_for_retrieval(self):
        c = Conversation()
        c.add("operator", "EQ-CMP-03, removal rate is uneven")
        c.add("agent", "Likely pad-conditioner wear. Center-to-edge or radial?")

        rewritten = "EQ-CMP-03 radial wafer troubleshooting"
        planned = {"intent": "retrieve", "standalone_query": rewritten,
                   "clarifying_question": None,
                   "rationale": "short follow-up rewritten using prior tool ID + topic"}

        retrieve_fn = MagicMock(return_value=([], "no_relevant_context"))

        with patch("agent.chat_agent.plan", return_value=planned):
            reply, trace = handle_turn(c, "radial", retrieve_fn, MagicMock())

        # retrieval must use the REWRITTEN query, not "radial"
        retrieve_fn.assert_called_once_with(rewritten, k=5)
        assert trace["query"] == rewritten
        assert "EQ-CMP-03" in trace["plan"]["standalone_query"]
        assert "radial" in trace["plan"]["standalone_query"].lower()

    def test_radial_rewrite_full_loop_with_claims(self):
        """End-to-end: rewritten query retrieves real chunks, generator
        produces a claim grounded in those chunks, critic verifies it."""
        c = Conversation()
        c.add("operator", "EQ-CMP-03, removal rate is uneven")
        c.add("agent", "Likely pad-conditioner wear. Center-to-edge or radial?")

        rewritten = "EQ-CMP-03 radial wafer troubleshooting"
        planned = {"intent": "retrieve", "standalone_query": rewritten,
                   "clarifying_question": None, "rationale": "rewrite"}

        chunks = [{"id": "cmp_primer_c0009",
                   "text": "...rings that correlate with the radial pattern "
                           "observed on the wafer."}]
        retrieve_fn = MagicMock(return_value=(chunks, "ok"))

        gen_result = {"abstained": False, "abstain_reason": None,
                       "claims": [{"text": "Radial pattern indicates carrier-head "
                                           "pressure imbalance.",
                                   "source_ids": ["cmp_primer_c0009"]}],
                       "follow_up_question": None,
                       "suggested_action": "Check the diamond-disk wear."}

        def fake_verify(raw, chunks_by_id):
            # real critic.verify_answer shape: pass through + add stripped_count
            out = dict(raw)
            out["stripped_count"] = 0
            return out

        with patch("agent.chat_agent.plan", return_value=planned), \
             patch("agent.chat_agent.generate", return_value=gen_result):
            reply, trace = handle_turn(c, "radial", retrieve_fn, fake_verify)

        retrieve_fn.assert_called_once_with(rewritten, k=5)
        assert "carrier-head pressure imbalance. [1]" in reply
        assert "Suggested action: Check the diamond-disk wear." in reply
        assert trace["verified"]["stripped_count"] == 0

    def test_short_followup_without_history_tool_id_not_magically_rewritten(self):
        """If the planner (correctly) decides NOT to rewrite -- e.g. there's
        no tool ID anywhere in history -- handle_turn() just uses whatever
        standalone_query the planner returned, including the raw message."""
        c = Conversation()
        c.add("operator", "Tell me about cleanroom gowning")
        c.add("agent", "Here's the gowning sequence...")

        planned = {"intent": "retrieve", "standalone_query": "radial",
                   "clarifying_question": None, "rationale": "no tool id to rewrite with"}
        retrieve_fn = MagicMock(return_value=([], "no_relevant_context"))

        with patch("agent.chat_agent.plan", return_value=planned):
            handle_turn(c, "radial", retrieve_fn, MagicMock())

        retrieve_fn.assert_called_once_with("radial", k=5)
