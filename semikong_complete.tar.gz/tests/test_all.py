"""
tests/test_all.py
=================
Comprehensive test suite for SemiKong agent — covers every fix from code review.

Run:
    cd /tmp/semikong && python -m pytest tests/test_all.py -v

No vLLM, no ChromaDB, no GPU required — everything is mocked.
"""
import sys, os, json, pickle, tempfile, shutil
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from unittest.mock import patch, MagicMock, PropertyMock

# ══════════════════════════════════════════════════════════════════════════════
# 1. SCHEMA TESTS — Optional typing + model structure
# ══════════════════════════════════════════════════════════════════════════════

class TestSchema:

    def test_claim_basic(self):
        from agent.schema import Claim
        c = Claim(text="Dishing causes W plug recess.", source_ids=["c001"])
        assert c.text == "Dishing causes W plug recess."
        assert c.source_ids == ["c001"]
        assert c.critic_verdict is None          # optional field defaults to None

    def test_claim_with_verdict(self):
        from agent.schema import Claim
        c = Claim(text="Test.", source_ids=["c001"], critic_verdict="SUPPORTED")
        assert c.critic_verdict == "SUPPORTED"

    def test_agent_answer_optional_fields(self):
        """Fix: str | None replaced with Optional[str] for Python 3.8 compat."""
        from agent.schema import AgentAnswer
        a = AgentAnswer(abstained=False)
        assert a.abstain_reason is None          # Optional[str] default
        assert a.suggested_action is None
        assert a.claims == []

    def test_agent_answer_with_claims(self):
        from agent.schema import AgentAnswer, Claim
        a = AgentAnswer(
            abstained=False,
            claims=[Claim(text="Test claim.", source_ids=["c001"])],
            suggested_action="Check slurry pH."
        )
        assert len(a.claims) == 1
        assert a.suggested_action == "Check slurry pH."

    def test_verified_answer_defaults(self):
        from agent.schema import VerifiedAnswer
        v = VerifiedAnswer(abstained=False)
        assert v.stripped_count == 0
        assert v.verified_claims == []
        assert v.trace == {}

    def test_verified_answer_full(self):
        from agent.schema import VerifiedAnswer, Claim
        v = VerifiedAnswer(
            abstained=False,
            verified_claims=[Claim(text="Test.", source_ids=["c001"],
                                   critic_verdict="SUPPORTED")],
            stripped_count=2,
            trace={"retrieval_status": "ok"}
        )
        assert v.stripped_count == 2
        assert v.verified_claims[0].critic_verdict == "SUPPORTED"


# ══════════════════════════════════════════════════════════════════════════════
# 2. GENERATOR TESTS — JSON parsing + source_id validation + error handling
# ══════════════════════════════════════════════════════════════════════════════

class TestGeneratorParsing:
    """Fix 1: json.loads replaced with _parse_json() — never raises."""

    def test_clean_json(self):
        from agent.generator import _parse_json
        raw = json.dumps({"abstained": False, "claims": [{"text":"X","source_ids":["c1"]}],
                          "abstain_reason": None, "suggested_action": None})
        result = _parse_json(raw)
        assert result["abstained"] is False
        assert result["claims"][0]["text"] == "X"

    def test_json_inside_markdown_fences(self):
        """LLMs often wrap output in ```json ... ``` — must be extracted."""
        from agent.generator import _parse_json
        raw = '```json\n{"abstained":false,"claims":[],"abstain_reason":null,"suggested_action":null}\n```'
        result = _parse_json(raw)
        assert result["abstained"] is False

    def test_json_with_prose_preamble(self):
        """LLM sometimes says 'Sure! Here is the answer:' before JSON."""
        from agent.generator import _parse_json
        raw = 'Sure, here is my answer:\n{"abstained":false,"claims":[{"text":"X","source_ids":["c1"]}],"abstain_reason":null,"suggested_action":"Check pad."}'
        result = _parse_json(raw)
        assert result["abstained"] is False
        assert result["claims"][0]["source_ids"] == ["c1"]

    def test_completely_invalid_json_returns_abstain(self):
        """Malformed output → safe abstain, never raises JSONDecodeError."""
        from agent.generator import _parse_json
        result = _parse_json("I cannot answer that question about dishing.")
        assert result["abstained"] is True
        assert "not valid JSON" in result["abstain_reason"]
        assert result["claims"] == []

    def test_empty_string_returns_abstain(self):
        from agent.generator import _parse_json
        result = _parse_json("")
        assert result["abstained"] is True

    def test_truncated_json_returns_abstain(self):
        from agent.generator import _parse_json
        result = _parse_json('{"abstained": false, "claims": [{"text": "inc')
        assert result["abstained"] is True


class TestGeneratorSourceIdValidation:
    """Fix 2: source_ids are validated against actually-retrieved chunks."""

    def _make_chunks(self):
        return [
            {"id": "real_c001", "text": "CMP dishing occurs when polishing pad deforms."},
            {"id": "real_c002", "text": "Reduce down force to fix dishing."},
        ]

    @patch("agent.generator._get_llm")
    def test_valid_source_ids_kept(self, mock_llm):
        """Claims citing real chunk IDs are kept as-is."""
        from agent.generator import generate
        mock_llm.return_value.invoke.return_value.content = json.dumps({
            "abstained": False,
            "claims": [{"text": "Dishing fix.", "source_ids": ["real_c001"]}],
            "abstain_reason": None, "suggested_action": None
        })
        result = generate("CMP dishing fix?", self._make_chunks())
        assert not result["abstained"]
        assert result["claims"][0]["source_ids"] == ["real_c001"]

    @patch("agent.generator._get_llm")
    def test_hallucinated_source_ids_stripped(self, mock_llm):
        """Claims citing non-existent IDs are dropped entirely."""
        from agent.generator import generate
        mock_llm.return_value.invoke.return_value.content = json.dumps({
            "abstained": False,
            "claims": [{"text": "Fake claim.", "source_ids": ["hallucinated_id"]}],
            "abstain_reason": None, "suggested_action": None
        })
        result = generate("any query", self._make_chunks())
        assert result["abstained"] is True
        assert result["claims"] == []

    @patch("agent.generator._get_llm")
    def test_mixed_ids_partial_strip(self, mock_llm):
        """Only the hallucinated IDs are removed; valid IDs remain."""
        from agent.generator import generate
        mock_llm.return_value.invoke.return_value.content = json.dumps({
            "abstained": False,
            "claims": [{"text": "Mixed claim.",
                        "source_ids": ["real_c001", "hallucinated_id"]}],
            "abstain_reason": None, "suggested_action": None
        })
        result = generate("query", self._make_chunks())
        assert not result["abstained"]
        assert result["claims"][0]["source_ids"] == ["real_c001"]

    @patch("agent.generator._get_llm")
    def test_llm_exception_returns_abstain(self, mock_llm):
        """Network/LLM failures return graceful abstain, never raise."""
        from agent.generator import generate
        mock_llm.return_value.invoke.side_effect = ConnectionError("vLLM unreachable")
        result = generate("query", self._make_chunks())
        assert result["abstained"] is True
        assert "LLM call failed" in result["abstain_reason"]

    def test_empty_chunks_returns_abstain(self):
        from agent.generator import generate
        result = generate("any query", [])
        assert result["abstained"] is True

    def test_env_vars_used(self):
        """Fix: MODEL_PATH and VLLM_URL from env — not hardcoded."""
        import agent.generator as gen
        assert "MODEL_PATH" in dir(gen) or hasattr(gen, "MODEL_PATH")
        assert "VLLM_URL"   in dir(gen) or hasattr(gen, "VLLM_URL")


# ══════════════════════════════════════════════════════════════════════════════
# 3. RETRIEVAL TESTS — path expansion, RRF, safe lookup, lazy init
# ══════════════════════════════════════════════════════════════════════════════

class TestRetrievalPaths:
    """Fix 1: ~ must be expanded via os.path.expanduser()."""

    def test_chroma_dir_not_literal_tilde(self):
        import agent.retrieval as ret
        assert not ret.CHROMA_DIR.startswith("~"), \
            f"CHROMA_DIR starts with ~: {ret.CHROMA_DIR}"

    def test_bm25_path_not_literal_tilde(self):
        import agent.retrieval as ret
        assert not ret.BM25_PATH.startswith("~"), \
            f"BM25_PATH starts with ~: {ret.BM25_PATH}"

    def test_env_override_also_expanded(self, monkeypatch):
        """Env vars with ~ are also expanded."""
        monkeypatch.setenv("CHROMA_DIR", "~/custom/chroma")
        import importlib
        import agent.retrieval as ret
        # The module was already loaded — test the function directly
        expanded = os.path.expanduser("~/custom/chroma")
        assert not expanded.startswith("~")
        assert "/" in expanded


class TestRetrievalRRF:
    """Fix 2: RRF formula is 1/(k+rank+1) not 1/(k+rank)."""

    def test_rrf_standard_formula(self):
        from agent.retrieval import rrf_merge
        # Single list: rank-0 should get 1/(60+0+1) = 1/61
        result = dict(rrf_merge([["A", "B", "C"]]))
        assert abs(result["A"] - 1/61) < 1e-9, f"Expected 1/61, got {result['A']}"
        assert abs(result["B"] - 1/62) < 1e-9
        assert abs(result["C"] - 1/63) < 1e-9

    def test_rrf_top_doc_not_1_over_k(self):
        """Regression: old formula gave 1/60 for rank-0, not 1/61."""
        from agent.retrieval import rrf_merge
        result = dict(rrf_merge([["A"]]))
        assert result["A"] != 1/60, "Old RRF formula still in use"

    def test_rrf_two_lists_merge_correctly(self):
        from agent.retrieval import rrf_merge
        # Doc in both lists at rank-0 gets higher score than doc in only one
        merged = dict(rrf_merge([["shared", "a"], ["shared", "b"]]))
        solo   = dict(rrf_merge([["solo"]]))
        assert merged["shared"] > list(solo.values())[0]

    def test_rrf_sorted_descending(self):
        from agent.retrieval import rrf_merge
        result = rrf_merge([["A", "B", "C", "D"]])
        scores = [s for _, s in result]
        assert scores == sorted(scores, reverse=True)

    def test_rrf_empty_rankings(self):
        from agent.retrieval import rrf_merge
        assert rrf_merge([]) == []
        assert rrf_merge([[]]) == []


class TestRetrievalSafeLookup:
    """Fix 3: id_to_chunk[i] → id_to_chunk.get(i) — no KeyError on ID mismatch."""

    def _make_bm25_data(self, chunks):
        from rank_bm25 import BM25Okapi
        tokenized = [c["text"].lower().split() for c in chunks]
        return {"bm25": BM25Okapi(tokenized), "chunks": chunks}

    def test_dense_id_not_in_bm25_is_skipped(self):
        """ChromaDB may contain IDs that don't exist in BM25 index. Must not crash."""
        import agent.retrieval as ret
        ret._reset()

        bm25_chunks = [
            {"id": "bm25_c001", "text": "CMP dishing fix slurry chemistry"},
            {"id": "bm25_c002", "text": "RIE etch rate silicon fluorine plasma"},
        ]

        mock_doc1 = MagicMock()
        mock_doc1.metadata = {"id": "dense_only_id"}  # not in BM25
        mock_doc2 = MagicMock()
        mock_doc2.metadata = {"id": "bm25_c001"}       # in BM25

        mock_chroma = MagicMock()
        mock_chroma.similarity_search_with_score.return_value = [
            (mock_doc1, 0.1), (mock_doc2, 0.2)
        ]

        with patch.object(ret, "_chroma", mock_chroma), \
             patch.object(ret, "_bm25", self._make_bm25_data(bm25_chunks)), \
             patch.object(ret, "_emb",  MagicMock()):
            chunks, status = ret.retrieve("CMP dishing")

        assert status == "ok"
        # dense_only_id was skipped; bm25_c001 returned
        ids = [c["id"] for c in chunks]
        assert "bm25_c001" in ids
        assert "dense_only_id" not in ids

    def test_metadata_key_fallback(self):
        """Handle legacy 'chunk_id' key as fallback to 'id'."""
        import agent.retrieval as ret
        ret._reset()

        bm25_chunks = [{"id": "c001", "text": "CMP process step"}]

        mock_doc = MagicMock()
        mock_doc.metadata = {"chunk_id": "c001"}  # old-style key, no "id"

        mock_chroma = MagicMock()
        mock_chroma.similarity_search_with_score.return_value = [(mock_doc, 0.1)]

        with patch.object(ret, "_chroma", mock_chroma), \
             patch.object(ret, "_bm25", self._make_bm25_data(bm25_chunks)), \
             patch.object(ret, "_emb",  MagicMock()):
            chunks, status = ret.retrieve("CMP")

        assert status == "ok"
        assert any(c["id"] == "c001" for c in chunks)

    def test_abstains_when_best_score_above_threshold(self):
        """Independent of FAKE_EMBEDDINGS env state: patch DISTANCE_THRESHOLD
        directly to a known value and use a score unambiguously above it."""
        import agent.retrieval as ret
        ret._reset()

        mock_doc = MagicMock()
        mock_doc.metadata = {"id": "c001"}
        mock_chroma = MagicMock()
        # 9.9 is above both the real-BGE default (0.5) and the
        # FakeEmbeddings default (1.47) — and above the patched value below.
        mock_chroma.similarity_search_with_score.return_value = [(mock_doc, 9.9)]

        with patch.object(ret, "_chroma", mock_chroma), \
             patch.object(ret, "_bm25", {"bm25": MagicMock(), "chunks": []}), \
             patch.object(ret, "_emb",  MagicMock()), \
             patch.object(ret, "DISTANCE_THRESHOLD", 0.5):
            chunks, status = ret.retrieve("far off domain")

        assert status == "no_relevant_context"
        assert chunks == []

    def test_lazy_init_does_not_run_at_import(self):
        """Fix: singletons must be None at import — not loaded eagerly."""
        import agent.retrieval as ret
        ret._reset()
        assert ret._emb    is None
        assert ret._chroma is None
        assert ret._bm25   is None


# ══════════════════════════════════════════════════════════════════════════════
# 4. CRITIC TESTS — HTTP errors, empty evidence, no mutation
# ══════════════════════════════════════════════════════════════════════════════

class TestCriticHttpErrors:
    """Fix 1+2: requests.post errors + missing raise_for_status."""

    def test_network_error_returns_not_supported(self):
        """Connection error → NOT_SUPPORTED, never raises."""
        from agent.critic import critique_claim
        with patch("agent.critic.requests.post") as mock_post:
            mock_post.side_effect = ConnectionError("vLLM unreachable")
            result = critique_claim("Claim text.", "Evidence text.")
        assert result == "NOT_SUPPORTED"

    def test_timeout_returns_not_supported(self):
        import requests as req_lib
        from agent.critic import critique_claim
        with patch("agent.critic.requests.post") as mock_post:
            mock_post.side_effect = req_lib.Timeout("timeout")
            result = critique_claim("Claim text.", "Evidence text.")
        assert result == "NOT_SUPPORTED"

    def test_http_500_returns_not_supported(self):
        """raise_for_status should be called — 500 must be caught."""
        import requests as req_lib
        from agent.critic import critique_claim
        with patch("agent.critic.requests.post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.raise_for_status.side_effect = req_lib.HTTPError("500")
            mock_post.return_value = mock_resp
            result = critique_claim("Claim text.", "Evidence text.")
        assert result == "NOT_SUPPORTED"

    def test_raise_for_status_is_called(self):
        """Verify raise_for_status() is actually invoked (not missing)."""
        from agent.critic import critique_claim
        with patch("agent.critic.requests.post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.json.return_value = {
                "choices": [{"message": {"content": "SUPPORTED"}}]
            }
            mock_post.return_value = mock_resp
            critique_claim("Claim.", "Evidence.")
        mock_resp.raise_for_status.assert_called_once()

    def test_supported_verdict_returned(self):
        from agent.critic import critique_claim
        with patch("agent.critic.requests.post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.json.return_value = {
                "choices": [{"message": {"content": "SUPPORTED"}}]
            }
            mock_post.return_value = mock_resp
            result = critique_claim("Claim.", "Evidence.")
        assert result == "SUPPORTED"

    def test_malformed_response_returns_not_supported(self):
        from agent.critic import critique_claim
        with patch("agent.critic.requests.post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.json.return_value = {}   # no "choices" key
            mock_post.return_value = mock_resp
            result = critique_claim("Claim.", "Evidence.")
        assert result == "NOT_SUPPORTED"


class TestCriticEmptyEvidence:
    """Fix 3: empty evidence → skip critic call immediately."""

    def test_empty_evidence_strips_claim_without_llm_call(self):
        """If source_ids are all missing from chunks_by_id, skip LLM entirely."""
        from agent.critic import verify_answer
        answer = {
            "abstained": False,
            "claims": [{"text": "A claim.", "source_ids": ["ghost_id"]}],
            "abstain_reason": None, "suggested_action": None
        }
        with patch("agent.critic.critique_claim") as mock_crit:
            result = verify_answer(answer, {})  # empty chunks_by_id
        mock_crit.assert_not_called()           # no LLM call wasted
        assert result["claims"] == []
        assert result["abstained"] is True

    def test_partially_missing_ids_uses_available_evidence(self):
        """If some source_ids exist, use what's there and still run critic."""
        from agent.critic import verify_answer
        answer = {
            "abstained": False,
            "claims": [{"text": "A claim.", "source_ids": ["real", "ghost"]}],
            "abstain_reason": None, "suggested_action": None
        }
        chunks_by_id = {"real": {"text": "Real evidence chunk."}}
        with patch("agent.critic.critique_claim", return_value="SUPPORTED") as mock_crit:
            result = verify_answer(answer, chunks_by_id)
        mock_crit.assert_called_once()
        assert len(result["claims"]) == 1


class TestCriticNoMutation:
    """Fix 4: verify_answer must NOT mutate the caller's answer_json."""

    def test_original_dict_unchanged(self):
        from agent.critic import verify_answer
        original = {
            "abstained": False,
            "claims": [{"text": "Claim.", "source_ids": ["c001"]}],
            "abstain_reason": None,
            "suggested_action": None,
        }
        original_claims_before = list(original["claims"])
        chunks_by_id = {"c001": {"text": "Evidence text for claim."}}

        with patch("agent.critic.critique_claim", return_value="NOT_SUPPORTED"):
            result = verify_answer(original, chunks_by_id)

        # result is modified
        assert result["claims"] == []
        # original is NOT modified
        assert original["claims"] == original_claims_before
        assert original["abstained"] is False

    def test_stripped_count_in_result_not_original(self):
        from agent.critic import verify_answer
        original = {
            "abstained": False,
            "claims": [{"text": "Claim.", "source_ids": ["c001"]}],
            "abstain_reason": None,
            "suggested_action": None,
        }
        chunks_by_id = {"c001": {"text": "Evidence."}}
        with patch("agent.critic.critique_claim", return_value="SUPPORTED"):
            result = verify_answer(original, chunks_by_id)
        assert "stripped_count" in result
        assert "stripped_count" not in original


class TestCriticVerdict:
    """Correctness tests for verdict logic."""

    def _run(self, verdict_token):
        from agent.critic import verify_answer
        answer = {
            "abstained": False,
            "claims": [{"text": "Claim.", "source_ids": ["c001"]}],
            "abstain_reason": None, "suggested_action": None,
        }
        chunks = {"c001": {"text": "Evidence."}}
        with patch("agent.critic.critique_claim", return_value=verdict_token):
            return verify_answer(answer, chunks)

    def test_supported_claim_kept(self):
        result = self._run("SUPPORTED")
        assert len(result["claims"]) == 1
        assert not result["abstained"]

    def test_not_supported_claim_stripped(self):
        result = self._run("NOT_SUPPORTED")
        assert result["claims"] == []
        assert result["abstained"] is True
        assert "failed critic" in result["abstain_reason"]

    def test_stripped_count_incremented(self):
        result = self._run("NOT_SUPPORTED")
        assert result["stripped_count"] == 1


# ══════════════════════════════════════════════════════════════════════════════
# 5. ORCHESTRATOR TESTS — error handling, trace merging, end-to-end
# ══════════════════════════════════════════════════════════════════════════════

class TestOrchestratorErrorHandling:
    """Fix 1: generate() wrapped in try/except."""

    def test_retrieval_error_returns_graceful_abstain(self):
        from agent.orchestrator import troubleshoot
        with patch("agent.orchestrator.retrieve", return_value=([], "error")):
            result = troubleshoot("any query")
        assert result["abstained"] is True
        assert "error" in result["abstain_reason"].lower()

    def test_no_relevant_context_returns_graceful_abstain(self):
        from agent.orchestrator import troubleshoot
        with patch("agent.orchestrator.retrieve", return_value=([], "no_relevant_context")):
            result = troubleshoot("off-domain query")
        assert result["abstained"] is True
        assert "knowledge base" in result["abstain_reason"]

    def test_generator_exception_returns_graceful_abstain(self):
        """Fix: generate() exception must become a graceful abstain, not a crash."""
        from agent.orchestrator import troubleshoot
        chunks = [{"id": "c001", "text": "some text"}]
        with patch("agent.orchestrator.retrieve", return_value=(chunks, "ok")), \
             patch("agent.orchestrator.generate", side_effect=RuntimeError("vLLM OOM")):
            result = troubleshoot("any query")
        assert result["abstained"] is True
        assert "vLLM OOM" in result["abstain_reason"]
        assert "c001" in result["trace"].get("retrieved_ids", [])

    def test_critic_exception_does_not_crash(self):
        """If critic raises, orchestrator must still return a valid dict."""
        from agent.orchestrator import troubleshoot
        chunks = [{"id": "c001", "text": "CMP text"}]
        gen_output = {"abstained": False, "claims": [{"text":"X","source_ids":["c001"]}],
                      "abstain_reason": None, "suggested_action": None}
        with patch("agent.orchestrator.retrieve",    return_value=(chunks, "ok")), \
             patch("agent.orchestrator.generate",    return_value=gen_output), \
             patch("agent.orchestrator.verify_answer", side_effect=RuntimeError("crash")):
            try:
                result = troubleshoot("CMP dishing")
                # If orchestrator doesn't handle this, that's still caught here
            except RuntimeError:
                pytest.fail("Orchestrator let critic exception propagate unhandled")


class TestOrchestratorTraceMerge:
    """Fix 2: trace must be merged, not overwritten."""

    def test_trace_merge_preserves_critic_keys(self):
        """Fix: final['trace'] = {...} was overwriting critic trace data."""
        from agent.orchestrator import troubleshoot
        chunks = [{"id": "c001", "text": "CMP text"}]
        gen_output = {"abstained": False,
                      "claims": [{"text": "CMP claim.", "source_ids": ["c001"]}],
                      "abstain_reason": None, "suggested_action": None}

        def mock_verify(answer, chunks_by_id):
            result = dict(answer)
            result["claims"] = answer["claims"]
            result["stripped_count"] = 0
            result["trace"] = {"critic_verdicts": ["SUPPORTED"]}   # critic added this
            return result

        with patch("agent.orchestrator.retrieve",    return_value=(chunks, "ok")), \
             patch("agent.orchestrator.generate",    return_value=gen_output), \
             patch("agent.orchestrator.verify_answer", side_effect=mock_verify):
            result = troubleshoot("CMP dishing")

        # Both critic keys AND retrieval keys must be present
        assert "critic_verdicts"  in result["trace"], "Critic trace was overwritten!"
        assert "retrieved_ids"    in result["trace"]
        assert "retrieval_status" in result["trace"]

    def test_retrieved_ids_in_trace(self):
        from agent.orchestrator import troubleshoot
        chunks = [{"id": "c001", "text": "t1"}, {"id": "c002", "text": "t2"}]
        gen_output = {"abstained": True, "abstain_reason": "test",
                      "claims": [], "suggested_action": None}
        with patch("agent.orchestrator.retrieve", return_value=(chunks, "ok")), \
             patch("agent.orchestrator.generate", return_value=gen_output), \
             patch("agent.orchestrator.verify_answer", return_value=gen_output):
            result = troubleshoot("query")
        assert set(result["trace"]["retrieved_ids"]) == {"c001", "c002"}


class TestOrchestratorEndToEnd:
    """Full pipeline with mocks — happy path and adversarial cases."""

    def _run(self, query, chunks, gen_output, critic_verdicts=None, run_critic=True):
        from agent.orchestrator import troubleshoot
        if critic_verdicts is not None:
            def mock_verify(answer, cbi):
                result = dict(answer)
                verified = []
                stripped = 0
                for claim, verdict in zip(answer.get("claims", []), critic_verdicts):
                    c = dict(claim)
                    c["critic_verdict"] = verdict
                    if verdict == "SUPPORTED":
                        verified.append(c)
                    else:
                        stripped += 1
                result["claims"] = verified
                result["stripped_count"] = stripped
                if not verified and not result.get("abstained"):
                    result["abstained"] = True
                    result["abstain_reason"] = "All claims failed critic."
                return result
            verify_patch = patch("agent.orchestrator.verify_answer", side_effect=mock_verify)
        else:
            verify_patch = patch("agent.orchestrator.verify_answer", return_value=gen_output)

        with patch("agent.orchestrator.retrieve", return_value=(chunks, "ok")), \
             patch("agent.orchestrator.generate",  return_value=gen_output), \
             verify_patch:
            return troubleshoot(query, run_critic=run_critic)

    def test_happy_path_returns_verified_claims(self):
        chunks = [{"id": "c001", "text": "Dishing caused by pad deformation."}]
        gen = {"abstained": False, "abstain_reason": None, "suggested_action": "Check pad.",
               "claims": [{"text": "Dishing fix: reduce force.", "source_ids": ["c001"]}]}
        result = self._run("CMP dishing?", chunks, gen, ["SUPPORTED"])
        assert not result["abstained"]
        assert len(result["claims"]) == 1
        assert result["claims"][0]["critic_verdict"] == "SUPPORTED"

    def test_all_claims_fail_critic_triggers_abstain(self):
        chunks = [{"id": "c001", "text": "CMP text."}]
        gen = {"abstained": False, "abstain_reason": None, "suggested_action": None,
               "claims": [{"text": "Wrong claim.", "source_ids": ["c001"]}]}
        result = self._run("query", chunks, gen, ["NOT_SUPPORTED"])
        assert result["abstained"] is True
        assert result["claims"] == []

    def test_no_critic_mode(self):
        """run_critic=False skips verify_answer but still returns valid structure."""
        from agent.orchestrator import troubleshoot
        chunks = [{"id": "c001", "text": "CMP"}]
        gen = {"abstained": False, "claims": [{"text": "X.", "source_ids": ["c001"]}],
               "abstain_reason": None, "suggested_action": None}
        with patch("agent.orchestrator.retrieve",     return_value=(chunks, "ok")), \
             patch("agent.orchestrator.generate",     return_value=gen), \
             patch("agent.orchestrator.verify_answer") as mock_verify:
            result = troubleshoot("query", run_critic=False)
        mock_verify.assert_not_called()
        assert "retrieved_ids" in result["trace"]

    def test_generator_abstain_propagates(self):
        """If generator abstains, skip critic and return immediately."""
        from agent.orchestrator import troubleshoot
        chunks = [{"id": "c001", "text": "text"}]
        gen = {"abstained": True, "abstain_reason": "Insufficient context.",
               "claims": [], "suggested_action": "Escalate."}
        with patch("agent.orchestrator.retrieve",     return_value=(chunks, "ok")), \
             patch("agent.orchestrator.generate",     return_value=gen), \
             patch("agent.orchestrator.verify_answer") as mock_verify:
            result = troubleshoot("query")
        # verify_answer still called — it handles the already-abstained case gracefully
        assert result is not None


# ══════════════════════════════════════════════════════════════════════════════
# 6. INTEGRATION SMOKE — imports don't crash, env vars respected
# ══════════════════════════════════════════════════════════════════════════════

class TestModuleImports:

    def test_schema_imports_cleanly(self):
        from agent.schema import Claim, AgentAnswer, VerifiedAnswer
        assert Claim
        assert AgentAnswer
        assert VerifiedAnswer

    def test_generator_imports_without_langchain(self):
        """Generator import must not require langchain at import time."""
        import agent.generator
        assert hasattr(agent.generator, "_parse_json")
        assert hasattr(agent.generator, "generate")

    def test_retrieval_import_does_not_call_hf_or_chroma(self):
        """Retrieval module must not touch HuggingFace or ChromaDB on import."""
        import agent.retrieval as ret
        ret._reset()
        # After import, singletons must still be None
        assert ret._emb    is None
        assert ret._chroma is None

    def test_critic_imports_without_requests_call(self):
        """No HTTP calls at import time."""
        import agent.critic
        assert hasattr(agent.critic, "critique_claim")
        assert hasattr(agent.critic, "verify_answer")

    def test_orchestrator_imports_clean(self):
        import agent.orchestrator
        assert hasattr(agent.orchestrator, "troubleshoot")

    def test_env_model_path(self, monkeypatch):
        """MODEL_PATH is read from env, not hardcoded."""
        monkeypatch.setenv("MODEL_PATH", "/custom/model/path")
        import importlib, agent.generator as gen
        importlib.reload(gen)
        assert gen.MODEL_PATH == "/custom/model/path"

    def test_env_vllm_url(self, monkeypatch):
        monkeypatch.setenv("VLLM_URL", "http://custom-host:9999/v1")
        import importlib, agent.generator as gen
        importlib.reload(gen)
        assert gen.VLLM_URL == "http://custom-host:9999/v1"
