"""
orchestrator.py — Main agent pipeline: retrieve → generate → critique.

Fixes applied vs original:
  1. generate() wrapped in try/except — returns graceful abstain on error
  2. retrieval "error" status handled explicitly
  3. final["trace"] = {} → final.setdefault("trace",{}).update(…) — merges, not overwrites
  4. run_critic=False path added for speed testing / Session 2 work
"""
import logging
from .retrieval import retrieve
from .generator import generate
from .critic    import verify_answer

log = logging.getLogger(__name__)


def troubleshoot(query: str, k: int = 5, run_critic: bool = True) -> dict:
    """
    Full troubleshooting pipeline.

    Returns a dict with keys:
        abstained       bool
        abstain_reason  str | None
        claims          list[dict]   (verified, cited claims)
        suggested_action str | None
        trace           dict         (latency, IDs, status for debugging)

    Never raises — all failures become abstained answers with a reason.
    """
    # ── Step 1: Retrieve ──────────────────────────────────────────────────────
    chunks, status = retrieve(query, k=k)

    if status == "no_relevant_context":
        return {
            "abstained":       True,
            "abstain_reason":  "No reliable source in knowledge base.",
            "claims":          [],
            "suggested_action":"Escalate to on-call engineer.",
            "trace":           {"retrieval_status": "below_threshold"},
        }

    if status == "error":
        return {
            "abstained":       True,
            "abstain_reason":  "Retrieval system error.",
            "claims":          [],
            "suggested_action":"Check ChromaDB and BM25 indices.",
            "trace":           {"retrieval_status": "error"},
        }

    # ── Step 2: Generate ──────────────────────────────────────────────────────
    try:
        raw = generate(query, chunks)
    except Exception as e:
        log.error("Generator error: %s", e)
        return {
            "abstained":       True,
            "abstain_reason":  f"Generator error: {e}",
            "claims":          [],
            "suggested_action":"Check vLLM server.",
            "trace":           {"error": str(e),
                                "retrieved_ids": [c["id"] for c in chunks]},
        }

    # ── Step 3: Critic ────────────────────────────────────────────────────────
    chunks_by_id = {c["id"]: c for c in chunks}

    if run_critic:
        try:
            final = verify_answer(raw, chunks_by_id)
        except Exception as e:
            log.error("Critic error: %s", e)
            final = dict(raw)
            final.setdefault("trace", {})["critic_error"] = str(e)
    else:
        final = dict(raw)
        final.setdefault("trace", {})["critic"] = "skipped"
        final.setdefault("stripped_count", 0)

    # Merge trace — Fix: was final["trace"] = {...} which silently overwrote critic trace
    final.setdefault("trace", {}).update({
        "retrieved_ids":    list(chunks_by_id.keys()),
        "retrieval_status": status,
    })

    return final
