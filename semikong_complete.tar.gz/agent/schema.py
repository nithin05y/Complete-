"""
schema.py — Pydantic models for the SemiKong agent pipeline.

Fixes applied vs original:
  - str | None  → Optional[str]  (Python 3.8/3.9 compatibility)
  - Added VerifiedAnswer model   (orchestrator return type)
  - Added critic_verdict field   (per-claim audit trail)
"""
from pydantic import BaseModel
from typing import List, Optional, Dict, Any


class Claim(BaseModel):
    text: str
    source_ids: List[str]
    critic_verdict: Optional[str] = None        # "SUPPORTED" | "NOT_SUPPORTED" | None


class AgentAnswer(BaseModel):
    abstained: bool
    abstain_reason: Optional[str] = None        # was: str | None  (3.10+ only)
    claims: List[Claim] = []
    suggested_action: Optional[str] = None


class VerifiedAnswer(BaseModel):
    abstained: bool
    abstain_reason: Optional[str] = None
    verified_claims: List[Claim] = []
    stripped_count: int = 0
    suggested_action: Optional[str] = None
    trace: Dict[str, Any] = {}
