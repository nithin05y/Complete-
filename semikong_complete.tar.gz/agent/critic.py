"""
critic.py — Per-claim SUPPORTED / NOT_SUPPORTED verification via vLLM.

Fixes applied vs original:
  1. requests.post() wrapped in try/except — returns NOT_SUPPORTED on any failure
  2. raise_for_status() added — catches HTTP 4xx/5xx from vLLM
  3. Empty evidence string short-circuits — no wasted LLM call
  4. answer_json is NOT mutated — operates on a shallow copy
  5. MODEL_PATH / VLLM_URL from env vars — no hardcoded paths
  6. stripped_count returned for observability
"""
import os
import logging
import requests
from typing import List, Dict

log = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
MODEL_PATH = os.getenv("MODEL_PATH", "/tmp/models/SEMIKONG-8b-GPTQ")
VLLM_URL   = os.getenv("VLLM_URL",   "http://localhost:8000/v1")

CRITIC_SYS = """\
You verify whether a CLAIM is supported by an EVIDENCE chunk.
Reply with exactly one token: SUPPORTED or NOT_SUPPORTED\
"""


# ── Core functions ────────────────────────────────────────────────────────────

def critique_claim(claim_text: str, evidence_text: str) -> str:
    """
    Ask vLLM whether claim_text is SUPPORTED by evidence_text.

    Uses guided_choice to force a single-token response.
    Returns "NOT_SUPPORTED" on any network/parse/HTTP error (safe fallback).
    Never raises.
    """
    payload = {
        "model": MODEL_PATH,
        "messages": [
            {"role": "system", "content": CRITIC_SYS},
            {"role": "user",
             "content": f"CLAIM:\n{claim_text}\n\nEVIDENCE:\n{evidence_text}"},
        ],
        "temperature": 0.0,
        "max_tokens": 4,
        "extra_body": {"guided_choice": ["SUPPORTED", "NOT_SUPPORTED"]},
    }
    try:
        resp = requests.post(
            f"{VLLM_URL}/chat/completions",
            json=payload,
            timeout=30,
        )
        resp.raise_for_status()                                    # Fix: was missing
        token = resp.json()["choices"][0]["message"]["content"].strip()
        return "NOT_SUPPORTED" if "NOT_SUPPORTED" in token else "SUPPORTED"
    except (requests.RequestException, ConnectionError,
            KeyError, ValueError, IndexError) as e:
        log.warning("Critic call failed: %s — defaulting NOT_SUPPORTED", e)
        return "NOT_SUPPORTED"                                     # Safe fallback


def verify_answer(answer_json: dict, chunks_by_id: Dict[str, dict]) -> dict:
    """
    Iterate over claims, strip those without valid sources or that fail critic.

    Fix: operates on a copy — does NOT mutate the caller's answer_json.
    Fix: empty evidence → strip immediately, no LLM call wasted.

    Returns a new dict with keys:
        claims          (verified list only)
        abstained       (True if all claims stripped and not already abstaining)
        abstain_reason
        stripped_count  (count of removed claims, for observability)
    """
    result = dict(answer_json)          # Fix: shallow copy — don't mutate input
    verified_claims: List[dict] = []
    stripped = 0

    for claim in result.get("claims", []):
        # Build evidence from source_ids that actually exist
        evidence_parts = [
            chunks_by_id[sid]["text"]
            for sid in claim.get("source_ids", [])
            if sid in chunks_by_id
        ]

        if not evidence_parts:
            # Fix: no evidence → skip critic call, just strip
            log.info("Stripping claim (no valid sources): %.60s", claim.get("text", ""))
            stripped += 1
            continue

        evidence = "\n\n".join(evidence_parts)
        verdict  = critique_claim(claim["text"], evidence)
        claim    = dict(claim)               # copy before mutating
        claim["critic_verdict"] = verdict

        if verdict == "SUPPORTED":
            verified_claims.append(claim)
        else:
            log.info("Stripped unsupported claim: %.60s", claim.get("text", ""))
            stripped += 1

    result["claims"]        = verified_claims
    result["stripped_count"] = stripped

    if not verified_claims and not result.get("abstained"):
        result["abstained"]      = True
        result["abstain_reason"] = "All claims failed critic verification."

    return result
