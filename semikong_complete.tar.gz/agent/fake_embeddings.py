"""
fake_embeddings.py
==================
Deterministic local embedding -- no network or HuggingFace download required.

Uses the "feature hashing" trick: each lowercase token (>=3 chars) is
hashed into one of 384 buckets with a deterministic +1/-1 sign, summed,
then L2-normalized. Unlike a pure random-per-text vector, this DOES
preserve keyword overlap: texts sharing many tokens land close together
(small cosine distance); texts sharing no tokens land near-orthogonal
(L2 distance ~sqrt(2)).

That's the property the CRAG distance-threshold gate in retrieval.py
needs offline: in-domain queries (sharing vocabulary with the corpus)
retrieve below threshold; off-domain queries correctly abstain.

Same output dimension (384) as BAAI/bge-small-en-v1.5 for drop-in swap.

Activate with env var:  FAKE_EMBEDDINGS=1
"""
import hashlib
import re
from typing import List

import numpy as np

_TOKEN_RE = re.compile(r"[a-z0-9]{3,}")


class FakeEmbeddings:
    """LangChain-Embeddings-compatible class requiring no model download."""

    DIM = 384

    def _tokenize(self, text: str) -> List[str]:
        return _TOKEN_RE.findall(text.lower())

    def _vec(self, text: str) -> List[float]:
        v = np.zeros(self.DIM, dtype=np.float32)
        tokens = self._tokenize(text) or [text.lower() or "empty"]

        for tok in tokens:
            digest = hashlib.sha256(tok.encode("utf-8")).digest()
            idx  = int.from_bytes(digest[:4], "big") % self.DIM
            sign = 1.0 if digest[4] % 2 == 0 else -1.0
            v[idx] += sign

        norm = float(np.linalg.norm(v))
        if norm > 0:
            v /= norm
        else:
            v[:] = 1.0 / np.sqrt(self.DIM)
        return v.tolist()

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return [self._vec(t) for t in texts]

    def embed_query(self, text: str) -> List[float]:
        return self._vec(text)
