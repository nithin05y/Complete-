"""
retrieval.py — Hybrid retrieval: ChromaDB dense + BM25 sparse + RRF merge.

Fixes applied vs original:
  1. ~ paths not expanded → os.path.expanduser() on all paths
  2. Module-level init (crashes import if files missing) → lazy singleton _load()
  3. Wrong metadata key "chunk_id" → .get("id") or .get("chunk_id") fallback
  4. id_to_chunk[i] KeyError → safe .get() with filter
  5. RRF formula 1/(k+rank) → 1/(k+rank+1)  (standard Reciprocal Rank Fusion)
  6. MODEL_PATH / paths read from env vars
"""
import os
import pickle
import logging
from typing import List, Tuple, Dict, Optional

log = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
CHROMA_DIR  = os.path.expanduser(os.getenv("CHROMA_DIR", "~/shared/chroma_db"))
BM25_PATH   = os.path.expanduser(os.getenv("BM25_PATH",  "~/shared/bm25.pkl"))
EMBED_MODEL = os.getenv("EMBED_MODEL", "BAAI/bge-small-en-v1.5")

# CRAG abstain threshold (L2 distance, lower = stricter = more abstentions).
# Default differs by embedding backend because the two produce very
# different distance distributions for "relevant" vs "irrelevant" docs:
#   - Real BGE embeddings: relevant docs typically land < 0.5
#   - FakeEmbeddings (feature-hashing, offline mode): relevant docs land
#     ~1.2-1.4, irrelevant ~1.5-1.6 (see fake_embeddings.py docstring)
# Always overridable via DISTANCE_THRESHOLD env var regardless of mode.
_DEFAULT_THRESHOLD = "1.47" if os.getenv("FAKE_EMBEDDINGS") == "1" else "0.5"
DISTANCE_THRESHOLD = float(os.getenv("DISTANCE_THRESHOLD", _DEFAULT_THRESHOLD))

COLLECTION_NAME = "semikong_fab_kb"

# ── Lazy singletons ───────────────────────────────────────────────────────────
_emb    = None
_chroma = None
_bm25   = None   # {"bm25": BM25Okapi, "chunks": [...]}


def _get_embeddings():
    """Return embedding function. FAKE_EMBEDDINGS=1 → deterministic local
    embedder (no network/HuggingFace download needed). Otherwise BGE-small."""
    if os.getenv("FAKE_EMBEDDINGS") == "1":
        from .fake_embeddings import FakeEmbeddings
        return FakeEmbeddings()
    from langchain_community.embeddings import HuggingFaceBgeEmbeddings
    return HuggingFaceBgeEmbeddings(
        model_name=EMBED_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )


def _load():
    """Load embedding model, ChromaDB, and BM25 index on first call."""
    global _emb, _chroma, _bm25
    if _emb is not None:
        return

    from langchain_community.vectorstores import Chroma

    log.info("Loading embeddings (FAKE_EMBEDDINGS=%s)", os.getenv("FAKE_EMBEDDINGS", "0"))
    _emb = _get_embeddings()
    _chroma = Chroma(
        collection_name=COLLECTION_NAME,
        persist_directory=CHROMA_DIR,
        embedding_function=_emb,
    )
    with open(BM25_PATH, "rb") as f:
        _bm25 = pickle.load(f)
    log.info("Retrieval components loaded (%d BM25 chunks)", len(_bm25["chunks"]))


def _reset():
    """Reset singletons (used in tests to force reload with different paths)."""
    global _emb, _chroma, _bm25
    _emb = _chroma = _bm25 = None


# ── Core functions ────────────────────────────────────────────────────────────

def rrf_merge(rankings: List[List[str]], k: int = 60) -> List[Tuple[str, float]]:
    """
    Reciprocal Rank Fusion merge.
    Standard formula: score(d) = Σ 1/(k + rank + 1)
    Fix: original was 1/(k+rank) which over-weights rank-0 documents.
    """
    scores: Dict[str, float] = {}
    for ranking in rankings:
        for rank, doc_id in enumerate(ranking):
            scores[doc_id] = scores.get(doc_id, 0.0) + 1.0 / (k + rank + 1)
    return sorted(scores.items(), key=lambda x: -x[1])


def retrieve(query: str, k: int = 5) -> Tuple[List[dict], str]:
    """
    Hybrid retrieval: dense (ChromaDB) + sparse (BM25) → RRF merge.

    Returns:
        (chunks, status)
        status: "ok" | "no_relevant_context" | "error"
    """
    try:
        _load()
    except Exception as e:
        log.error("Retrieval load failed: %s", e)
        return [], "error"

    # ── Dense (ChromaDB) ──────────────────────────────────────────────────────
    try:
        dense = _chroma.similarity_search_with_score(query, k=20)
    except Exception as e:
        log.error("ChromaDB query failed: %s", e)
        return [], "error"

    if not dense or dense[0][1] > DISTANCE_THRESHOLD:
        best = f"{dense[0][1]:.4f}" if dense else "none"
        log.info("Abstaining: best_dist=%s > threshold=%s", best, DISTANCE_THRESHOLD)
        return [], "no_relevant_context"

    # Extract chunk IDs — handle both "id" and legacy "chunk_id" metadata keys
    dense_ids: List[str] = []
    for doc, _ in dense:
        cid = doc.metadata.get("id") or doc.metadata.get("chunk_id")
        if cid:
            dense_ids.append(str(cid))

    # ── Sparse (BM25) ─────────────────────────────────────────────────────────
    tokenized_q = query.lower().split()
    bm25_scores = _bm25["bm25"].get_scores(tokenized_q)
    all_chunks  = _bm25["chunks"]

    sparse_ranked = sorted(range(len(bm25_scores)), key=lambda i: -bm25_scores[i])[:20]
    sparse_ids = [all_chunks[i]["id"] for i in sparse_ranked if i < len(all_chunks)]

    # ── RRF merge ─────────────────────────────────────────────────────────────
    merged     = rrf_merge([dense_ids, sparse_ids])[:k]
    id_to_chunk = {c["id"]: c for c in all_chunks}

    # Safe lookup — skip IDs absent from BM25 index (index/DB mismatch protection)
    results = [id_to_chunk[cid] for cid, _ in merged if cid in id_to_chunk]
    return results, "ok"
