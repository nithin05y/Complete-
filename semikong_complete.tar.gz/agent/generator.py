"""
generator.py — Structured answer generation via vLLM OpenAI-compatible API.

Fixes applied vs original:
  1. json.loads() wrapped in _parse_json() with regex fallback + safe abstain default
  2. Module-level LLM instance → lazy factory _get_llm()
  3. openai_api_base (deprecated) → base_url
  4. MODEL_PATH / VLLM_URL read from env vars — no hardcoded paths
  5. source_ids validated against provided chunks; phantom IDs stripped
  6. LLM call wrapped in try/except — returns abstain on network/LLM error
"""
import json
import re
import os
import logging
from typing import List, Dict

log = logging.getLogger(__name__)

# ── Config (all overridable via env) ─────────────────────────────────────────
MODEL_PATH = os.getenv("MODEL_PATH", "/tmp/models/SEMIKONG-8b-GPTQ")
VLLM_URL   = os.getenv("VLLM_URL",   "http://localhost:8000/v1")

GENERATOR_SYS = """\
You are a shopfloor troubleshooting assistant for semiconductor fab operators.
Answer ONLY from the retrieved context provided. Every claim MUST cite its source_id(s).
If context is insufficient, set abstained=true and explain in abstain_reason.

Return STRICT JSON only, matching this schema:
{
  "abstained": bool,
  "abstain_reason": string or null,
  "claims": [{"text": "...", "source_ids": ["c001", ...]}],
  "suggested_action": string or null
}
No prose outside the JSON.\
"""

# ── Helpers ───────────────────────────────────────────────────────────────────

def _get_llm():
    """Lazy factory — model/URL resolved from env at call time, not at import."""
    from langchain_openai import ChatOpenAI
    return ChatOpenAI(
        model=MODEL_PATH,
        base_url=VLLM_URL,          # Fix: was deprecated openai_api_base
        openai_api_key="EMPTY",
        temperature=0.0,
        max_tokens=800,
    )


def _parse_json(raw: str) -> dict:
    """
    Parse LLM output to dict.
    Tries strict parse first; falls back to regex extraction;
    finally returns a safe abstained answer rather than raising.
    """
    # 1. Strict
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    # 2. Strip markdown fences and retry
    cleaned = re.sub(r"```(?:json)?\n?", "", raw).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # 3. Extract first {...} block
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            pass

    log.warning("Generator: JSON parse failed on output: %s", raw[:120])
    return {
        "abstained": True,
        "abstain_reason": "Model output was not valid JSON.",
        "claims": [],
        "suggested_action": "Escalate to on-call engineer.",
    }


# ── Public API ────────────────────────────────────────────────────────────────

def generate(query: str, chunks: List[Dict]) -> dict:
    """
    Call the generator LLM and return a parsed answer dict.
    Always returns a dict with keys: abstained, abstain_reason, claims, suggested_action.
    Never raises — errors become abstained answers with a reason string.
    """
    if not chunks:
        return {
            "abstained": True,
            "abstain_reason": "No context chunks provided.",
            "claims": [],
            "suggested_action": "Escalate to on-call engineer.",
        }

    # Build context string
    ctx  = "\n\n".join(f"[{c['id']}] {c['text']}" for c in chunks)
    user = f"Operator query:\n{query}\n\nRetrieved context:\n{ctx}"

    try:
        llm = _get_llm()
        raw = llm.invoke([
            {"role": "system", "content": GENERATOR_SYS},
            {"role": "user",   "content": user},
        ]).content
    except Exception as e:
        log.error("Generator LLM call failed: %s", e)
        return {
            "abstained": True,
            "abstain_reason": f"LLM call failed: {e}",
            "claims": [],
            "suggested_action": "Check vLLM server.",
        }

    result = _parse_json(raw)

    # Validate source_ids — strip any IDs the LLM hallucinated
    valid_ids = {c["id"] for c in chunks}
    for claim in result.get("claims", []):
        claim["source_ids"] = [s for s in claim.get("source_ids", []) if s in valid_ids]

    # Drop claims that have no valid sources after filtering
    result["claims"] = [c for c in result.get("claims", []) if c.get("source_ids")]

    # If all claims were stripped and not already abstaining
    if not result["claims"] and not result.get("abstained"):
        result["abstained"] = True
        result["abstain_reason"] = "All cited sources were invalid after validation."

    return result
