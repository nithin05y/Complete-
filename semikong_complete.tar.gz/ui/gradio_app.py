#!/usr/bin/env python3
"""
ui/gradio_app.py — Fab Troubleshooting Agent chat UI.

Two-column layout:
  - Left:  chat (operator <-> agent), powered by agent.chat_agent.handle_turn()
  - Right: trace panel for THIS turn — intent, planner rationale, rewritten
           query, retrieved chunks, and how many claims the critic accepted
           vs stripped. This panel is the "wow factor": it makes the
           planner's query-rewrite (e.g. "radial" -> "EQ-CMP-03 radial wafer
           troubleshooting") visible to the audience.

One-time setup:
    pip install gradio --break-system-packages

Run (from the semikong_agent/ project root):
    python -m ui.gradio_app
    # or: python ui/gradio_app.py

Requires the mock vLLM server running (bash start_server.sh) and the
corpus already ingested (bash run_demo.sh) — same prerequisites as ask.py.
"""
import os
import sys
import pickle

# ── Locate project root regardless of how this file is invoked ─────────────
HERE = os.path.dirname(os.path.abspath(__file__))          # .../ui
ROOT = os.path.dirname(HERE)                                 # project root

os.environ["FAKE_EMBEDDINGS"] = "1"
os.environ["CHROMA_DIR"] = os.path.join(ROOT, "chroma_db")
os.environ["BM25_PATH"]  = os.path.join(ROOT, "bm25.pkl")
os.environ.setdefault("VLLM_URL",   "http://localhost:8000/v1")
os.environ.setdefault("MODEL_PATH", "mock-semikong")

sys.path.insert(0, ROOT)

import gradio as gr

from agent.chat_agent import Conversation, handle_turn
from agent.retrieval import retrieve as _base_retrieve
from agent.critic import verify_answer

# Use topic_boost's tag-aware retrieval (SECS/GEM, CMP, cleanroom) if the
# topic_boost/ package is present in this project; otherwise fall back to
# plain retrieve(), unchanged. Either way this keeps the same
# (query, k=5) -> (chunks, status) signature handle_turn() expects.
try:
    from topic_boost.retrieval_topic_boost import retrieve_with_topic_boost

    def retrieve(query, k=5):
        chunks, status, _tag = retrieve_with_topic_boost(query, k=k)
        return chunks, status
except ImportError:
    retrieve = _base_retrieve


def _load_chunk_count() -> int:
    bm25_path = os.environ["BM25_PATH"]
    if not os.path.exists(bm25_path):
        return 0
    with open(bm25_path, "rb") as f:
        data = pickle.load(f)
    return len(data.get("chunks", []))


N_CHUNKS = _load_chunk_count()


# ── Trace panel formatting ──────────────────────────────────────────────────

def _format_trace(trace: dict, escalated: bool) -> str:
    if escalated:
        lines = ["**Status: 🚨 ESCALATED** — handed off to on-call engineer.\n"]
    else:
        lines = []

    lines.append(f"**Intent:** `{trace.get('intent', '?')}`")

    plan = trace.get("plan") or {}
    if plan.get("rationale"):
        lines.append(f"**Planner rationale:** {plan['rationale']}")
    if plan.get("standalone_query"):
        lines.append(f"**Rewritten query:** `{plan['standalone_query']}`")
    if plan.get("clarifying_question"):
        lines.append(f"**Clarifying question:** {plan['clarifying_question']}")

    if trace.get("abstained"):
        lines.append("\n**Result:** abstained at retrieval (below relevance threshold)")

    verified = trace.get("verified")
    if verified:
        n_claims   = len(verified.get("claims", []))
        n_stripped = verified.get("stripped_count", 0)
        if verified.get("abstained"):
            lines.append(f"\n**Critic:** all claims rejected "
                          f"({n_stripped} stripped) -> abstained")
        else:
            lines.append(f"\n**Critic:** {n_claims} claim(s) accepted, "
                          f"{n_stripped} stripped")
        if verified.get("follow_up_question"):
            lines.append(f"**Follow-up asked:** {verified['follow_up_question']}")
        if verified.get("suggested_action"):
            lines.append(f"**Suggested action:** {verified['suggested_action']}")

    chunks = trace.get("chunks")
    if chunks:
        lines.append(f"\n**Retrieved chunks ({len(chunks)}):**")
        for c in chunks:
            preview = c["text"][:140].replace("\n", " ").strip()
            lines.append(f"- `[{c['id']}]` {preview}…")

    return "\n\n".join(lines)


# ── Chat callbacks ───────────────────────────────────────────────────────────

def on_send(message, chat_history, state):
    message = (message or "").strip()
    if not message:
        return "", chat_history or [], state, _placeholder_trace()

    if state is None:
        state = Conversation()

    reply, trace = handle_turn(state, message, retrieve, verify_answer)

    chat_history = (chat_history or []) + [
        {"role": "user", "content": message},
        {"role": "assistant", "content": reply},
    ]
    return "", chat_history, state, _format_trace(trace, state.escalated)


def on_clear():
    return [], None, _placeholder_trace()


def _placeholder_trace() -> str:
    return "_Trace for the next turn will appear here._"


# ── UI ────────────────────────────────────────────────────────────────────

with gr.Blocks(title="Fab Troubleshooting Agent") as demo:
    gr.Markdown(
        f"# 🛠️ Fab Shopfloor Troubleshooting Agent\n"
        f"Multi-turn conversational agent over **{N_CHUNKS:,} document "
        f"section(s)**. Mock SemiKong backend — see README for connecting "
        f"the real model."
    )

    state = gr.State(value=None)

    with gr.Row():
        with gr.Column(scale=2):
            chatbox = gr.Chatbot(height=480, label="Operator ↔ Agent")
            txt = gr.Textbox(
                placeholder="Describe symptom, paste alarm code, or ask a question…",
                show_label=False, autofocus=True,
            )
            with gr.Row():
                send  = gr.Button("Send", variant="primary")
                clear = gr.Button("New conversation")

        with gr.Column(scale=1):
            gr.Markdown("### Agent trace (this turn)")
            trace_md = gr.Markdown(value=_placeholder_trace())

    send.click(on_send, [txt, chatbox, state], [txt, chatbox, state, trace_md])
    txt.submit(on_send, [txt, chatbox, state], [txt, chatbox, state, trace_md])
    clear.click(on_clear, outputs=[chatbox, state, trace_md])

    gr.Examples(
        label="Try the DEMO-1 sequence (send one at a time, in order)",
        examples=[
            ["I have a problem with CMP"],
            ["EQ-CMP-03, removal rate is uneven"],
            ["Radial"],
        ],
        inputs=txt,
    )


if __name__ == "__main__":
    print(f"\nLoaded {N_CHUNKS:,} document sections.")
    print("Starting chat UI... (press CTRL+C to stop)\n")
    demo.launch(server_name="0.0.0.0", server_port=7861, share=True,
                theme=gr.themes.Soft())
