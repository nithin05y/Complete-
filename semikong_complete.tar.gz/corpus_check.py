#!/usr/bin/env python3
"""
corpus_check.py — Run a handful of diverse queries against your corpus and
print exactly what got retrieved (which chunks, from which source files)
and how the critic verified the answer, for each one.

This is the "for each document" check in one command -- no need to click
through the chat UI multiple times.

Prerequisite: the mock vLLM server must be running.
    bash start_server.sh

Run:
    python corpus_check.py
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
os.environ["FAKE_EMBEDDINGS"] = "1"
os.environ["CHROMA_DIR"] = os.path.join(HERE, "chroma_db")
os.environ["BM25_PATH"]  = os.path.join(HERE, "bm25.pkl")
os.environ.setdefault("VLLM_URL",   "http://localhost:8000/v1")
os.environ.setdefault("MODEL_PATH", "mock-semikong")
sys.path.insert(0, HERE)

from agent.chat_agent import Conversation, handle_turn
from agent.retrieval import retrieve
from agent.critic import verify_answer


def _abstained(trace: dict) -> bool:
    """Self-contained abstain check (doesn't depend on is_abstained() being
    present in agent/chat_agent.py yet)."""
    if trace.get("abstained"):
        return True
    return bool((trace.get("verified") or {}).get("abstained"))


# Each of these targets a different topic/source so you can see how the
# agent does across the breadth of your corpus, not just the CMP/radial path.
QUERIES = [
    "CMP dishing on tungsten plugs",
    "cleanroom gowning sequence",
    "Explain the SECS/GEM Stream and Function message structure",
    "What is reactive ion etching?",
    "Explain ion implantation dose and energy",
    "What types of vacuum pumps are used in semiconductor fab equipment?",
    "What is the photolithography exposure process?",
]


def source_of(chunk_id: str) -> str:
    """'fundamentals_of_semicond_c1842' -> 'fundamentals_of_semicond'"""
    return re.sub(r"_c\d{4}$", "", chunk_id)


def main():
    for i, q in enumerate(QUERIES, 1):
        print("=" * 78)
        print(f"[{i}/{len(QUERIES)}] QUERY: {q}")
        print("-" * 78)

        convo = Conversation()
        reply, trace = handle_turn(convo, q, retrieve, verify_answer)

        chunks = trace.get("chunks") or []
        if chunks:
            print(f"Retrieved {len(chunks)} chunk(s):")
            for ch in chunks:
                print(f"  - {ch['id']:35s}  (from {source_of(ch['id'])})")
        else:
            print("Retrieved: (none -- below relevance threshold)")

        verified = trace.get("verified")
        if verified:
            n_ok = len(verified.get("claims", []))
            n_stripped = verified.get("stripped_count", 0)
            print(f"Critic: {n_ok} accepted, {n_stripped} stripped")

        print(f"Abstained: {_abstained(trace)}")
        print()
        print("Reply:")
        print(reply)
        print()

    print("=" * 78)
    print("Done. Look for: (a) does each query find chunks from the file(s)")
    print("you'd expect, and (b) is 'accepted' > 0 (not abstained) for the")
    print("on-topic queries?")


if __name__ == "__main__":
    main()
