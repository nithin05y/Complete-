"""
mock_vllm/server.py
===================
FastAPI mock of vLLM's OpenAI-compatible /v1/chat/completions endpoint.

v3 adds TWO new roles on top of v2's generator+critic, all served by the
SAME mocked model (matching the real architecture: one LLM, three system
prompts):

  PLANNER call (chat_agent.PLANNER_SYS)
    System prompt contains "planning module".
    -> Returns {"intent","standalone_query","clarifying_question","rationale"}
       Routes smalltalk / clarify / retrieve / escalate based on the
       latest operator message + conversation history. The key behaviour:
       a SHORT follow-up ("radial") with no tool ID of its own, when the
       history contains a tool ID (e.g. EQ-CMP-03) from an earlier
       retrieve-intent turn, is REWRITTEN into a standalone query that
       folds in that tool ID + topic + the follow-up word — e.g.
       "EQ-CMP-03 CMP radial wafer unevenness troubleshooting".
       This is the mock implementation of "THE DEFINING FEATURE" (TS-05).

  V3 CONVERSATIONAL GENERATOR call (chat_agent.GEN_SYS)
    System prompt contains "follow_up_question" (unique to v3's schema).
    -> Returns {"abstained","abstain_reason","claims","follow_up_question",
                "suggested_action"}, citing real chunk_ids from context,
       routed on the latest operator message (not the full context block).

  V2 GENERATOR call (generator.GENERATOR_SYS) -- unchanged, kept for
    backward compatibility with demo.py / ask.py's single-shot pipeline.
    -> Returns {"abstained","abstain_reason","claims","suggested_action"}

  CRITIC call (extra_body.guided_choice)
    -> SUPPORTED / NOT_SUPPORTED via lexical-overlap heuristic. Unchanged.
"""
import json
import os
import re
import time
from typing import List, Optional

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="SemiKong Mock vLLM Server", version="2.0")

MODEL_ID = os.getenv("MODEL_PATH", "/tmp/models/SEMIKONG-8b-GPTQ")


# ── Request schema ────────────────────────────────────────────────────────────

class Message(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    model: str
    messages: List[Message]
    temperature: float = 0.0
    max_tokens: int = 512
    extra_body: Optional[dict] = None


# ── Shared helpers ────────────────────────────────────────────────────────────

def _system_prompt(req: ChatRequest) -> str:
    return next((m.content for m in req.messages if m.role == "system"), "")


def _user_message(req: ChatRequest) -> str:
    return next((m.content for m in req.messages if m.role == "user"), "")


_CHUNK_BLOCK_RE = re.compile(
    r"\[([\w\-]+_c\d{4})\]\s*(.*?)(?=\n\n\[|\n\nRespond to the operator|\Z)",
    re.DOTALL,
)


def _extract_chunk_blocks(text: str) -> List[tuple]:
    """[(chunk_id, chunk_text), ...] in the order they appear in the context."""
    return [(m.group(1), m.group(2).strip()) for m in _CHUNK_BLOCK_RE.finditer(text)]


_HEADING_RE = re.compile(r"^(?:\d+(?:\.\d+)*\.?\s+)?[A-Z0-9][A-Z0-9 \-/&,]{3,60}$")


def _claim_from_chunk(chunk_text: str, max_len: int = 220) -> str:
    """
    Build a claim by lightly trimming the chunk's OWN text -- this is what
    a real LLM grounding its answer in context would effectively produce,
    and it guarantees high lexical overlap with the cited evidence (so the
    critic accepts it) regardless of what's actually in the corpus.
    """
    text = chunk_text.strip()
    lines = text.split("\n", 1)
    if len(lines) == 2 and _HEADING_RE.match(lines[0].strip()):
        text = lines[1]
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) <= max_len:
        return text
    truncated = text[:max_len]
    cut = truncated.rfind(". ")
    if cut > 40:
        return truncated[:cut + 1]
    return truncated.rsplit(" ", 1)[0] + "..."


def _grounded_claims(blocks: List[tuple], max_claims: int = 5) -> List[dict]:
    """Build up to `max_claims` claims from retrieved chunks, skipping any
    chunk whose text is too short/junky to form a real claim (occasional
    PDF-extraction artifacts in large corpora). Default of 5 matches
    retrieve(query, k=5) -- use everything that was retrieved, not just
    the top 2."""
    claims = []
    for chunk_id, chunk_text in blocks:
        claim_text = _claim_from_chunk(chunk_text)
        if len(re.findall(r"[A-Za-z]{4,}", claim_text)) < 4:
            continue
        claims.append({"text": claim_text, "source_ids": [chunk_id]})
        if len(claims) >= max_claims:
            break
    return claims


OFF_DOMAIN_KEYWORDS = [
    "sourdough", "bread recipe", "pasta", "football", "tourist",
    "capital of", "movie", "song lyrics", "weather forecast",
]


def _is_off_domain(text: str) -> bool:
    low = text.lower()
    return any(kw in low for kw in OFF_DOMAIN_KEYWORDS)


# ════════════════════════════════════════════════════════════════════════════
# CRITIC  (unchanged from v2)
# ════════════════════════════════════════════════════════════════════════════

def _is_critic_call(req: ChatRequest) -> bool:
    if req.extra_body and "guided_choice" in req.extra_body:
        return True
    return any("NOT_SUPPORTED" in m.content for m in req.messages)


_STOPWORDS = {"that", "this", "from", "with", "have", "been", "will",
              "should", "when", "where", "into", "than", "then", "their"}


def _run_critic(req: ChatRequest) -> str:
    user_msg = _user_message(req)

    m_claim = re.search(r"CLAIM:\s*\n(.*?)(?:\n\nEVIDENCE:|$)", user_msg, re.DOTALL)
    m_evid  = re.search(r"EVIDENCE:\s*\n(.*)$", user_msg, re.DOTALL)
    if not m_claim or not m_evid:
        return "NOT_SUPPORTED"

    claim_words = {w for w in re.findall(r"[a-z]{4,}", m_claim.group(1).lower())
                   if w not in _STOPWORDS}
    evid_words  = set(re.findall(r"[a-z]{4,}", m_evid.group(1).lower()))

    if not claim_words:
        return "NOT_SUPPORTED"

    overlap = claim_words & evid_words
    ratio   = len(overlap) / len(claim_words)
    return "SUPPORTED" if ratio >= 0.3 else "NOT_SUPPORTED"


# ════════════════════════════════════════════════════════════════════════════
# PLANNER  (new in v3)
# ════════════════════════════════════════════════════════════════════════════

_TOOL_ID_RE   = re.compile(r"\b([A-Za-z]{2,4}-[A-Za-z0-9]{2,6}-\d{1,3})\b")
_GREETING_RE  = re.compile(r"\b(hello|hi|hey|thanks|thank you|bye|goodbye|good morning|good afternoon)\b")
_IDENTITY_RE  = re.compile(
    r"\b(who are you|what are you|what is this|what's this|"
    r"what can you do|what do you do|tell me about yourself|"
    r"introduce yourself|your name|what's your name|"
    r"are you (?:an?\s+)?(?:ai|bot|robot|chatgpt|llm|gpt)|"
    r"who (?:r|are) ?u\b|what (?:r|are) ?u\b|"
    r"who(?:'s|s| is) this|describe yourself|"
    r"tell me (?:who|what) you are|tell me about you|"
    r"what(?:'s| is) your (?:purpose|job|role))\b"
)
_ESCALATE_RE  = re.compile(r"\b(human|escalate|emergency|supervisor|manager now|urgent)\b")
_VAGUE_RE     = re.compile(r"\bi\s*(?:'ve\s+got|have|got|am having|am facing)\b.*\b(problem|issue|trouble)\b")
_TECH_KW_RE   = re.compile(
    r"\b(cmp|etch|secs|gem|hsms|cleanroom|gowning|removal|slurry|dishing|"
    r"wafer|polish|alarm|fault|recipe|plasma|deposition|implant|lithography)\b"
)

# topic hint -> phrase used when rewriting a short follow-up
_TOPIC_HINTS = [
    (re.compile(r"\b(cmp|polish|remov|dish|slurry|pad)\b"), "CMP"),
    (re.compile(r"\betch\b"), "etch"),
    (re.compile(r"\b(secs|gem|hsms)\b"), "SECS/GEM"),
    (re.compile(r"\b(cleanroom|gown)\b"), "cleanroom"),
]


def _parse_history(user_msg: str) -> List[tuple]:
    """Extract [(role, content), ...] from 'Conversation so far:\\n...' block."""
    m = re.search(r"Conversation so far:\s*\n(.*?)\n\nDecide next action", user_msg, re.DOTALL)
    block = m.group(1) if m else user_msg
    turns = []
    for line in block.split("\n"):
        line = line.strip()
        if line.startswith("OPERATOR: "):
            turns.append(("operator", line[len("OPERATOR: "):]))
        elif line.startswith("AGENT: "):
            turns.append(("agent", line[len("AGENT: "):]))
    return turns


def _planner_response(req: ChatRequest) -> dict:
    user_msg = _user_message(req)
    turns = _parse_history(user_msg)

    if not turns:
        return {"intent": "retrieve", "standalone_query": "",
                "clarifying_question": None, "rationale": "empty_history"}

    latest = turns[-1][1]
    latest_lower = latest.lower().strip()
    word_count = len(latest_lower.split())
    history_lower = " ".join(c.lower() for _, c in turns)

    # 1. Escalate — operator danger/frustration signals
    if _ESCALATE_RE.search(latest_lower):
        return {"intent": "escalate", "standalone_query": None,
                "clarifying_question": None,
                "rationale": "escalation keywords detected"}

    # 2. Smalltalk — short greeting, no technical content
    has_tool_id_latest = bool(_TOOL_ID_RE.search(latest))
    if (word_count <= 3 and _GREETING_RE.search(latest_lower)
            and not has_tool_id_latest and not _TECH_KW_RE.search(latest_lower)):
        return {"intent": "smalltalk", "standalone_query": None,
                "clarifying_question": None,
                "rationale": "greeting/smalltalk detected"}

    # 2b. Identity / capability questions ("who are you", "what can you
    # do") -- answer with a self-introduction instead of falling through
    # to retrieval, where FakeEmbeddings would return irrelevant textbook
    # chunks for a question that isn't actually in the corpus.
    if (_IDENTITY_RE.search(latest_lower)
            and not has_tool_id_latest and not _TECH_KW_RE.search(latest_lower)):
        return {"intent": "smalltalk", "standalone_query": None,
                "clarifying_question": None,
                "rationale": "identity/capability question detected"}

    # 3. Clarify — vague "I have a problem/issue" with no tool ID anywhere yet
    if _VAGUE_RE.search(latest_lower) and not _TOOL_ID_RE.search(history_lower):
        return {"intent": "clarify", "standalone_query": None,
                "clarifying_question": "Which tool ID, and what's the specific symptom?",
                "rationale": "vague request, no tool ID or symptom yet"}

    # 4. THE KEY CASE — short follow-up with no tool ID/technical content of
    #    its own, but history has a tool ID from an earlier retrieve turn.
    #    Rewrite into a standalone query (TS-05 / "radial").
    if (word_count <= 3 and not has_tool_id_latest
            and not _TECH_KW_RE.search(latest_lower)):
        m = _TOOL_ID_RE.search(history_lower) or _TOOL_ID_RE.search(
            " ".join(c for _, c in turns)
        )
        if m:
            tool_id = m.group(1).upper()
            topic = ""
            for pattern, label in _TOPIC_HINTS:
                if pattern.search(history_lower):
                    topic = label
                    break
            # Short, retrieval-friendly rewrite:
            #   <TOOL_ID> [<TOPIC, only if tool ID doesn't already imply it>]
            #   <follow-up word> wafer troubleshooting
            # Keeping it tight avoids diluting the hashed-embedding query
            # with redundant tokens (e.g. "CMP" appearing twice when the
            # tool ID already contains "cmp").
            parts = [tool_id]
            if topic and topic.lower().replace("/", "") not in tool_id.lower():
                parts.append(topic)
            parts += [latest_lower, "wafer", "troubleshooting"]
            standalone = re.sub(r"\s+", " ", " ".join(parts)).strip()
            return {"intent": "retrieve", "standalone_query": standalone,
                    "clarifying_question": None,
                    "rationale": "short follow-up rewritten using prior tool ID + topic"}

    # 5. Default — substantive question, retrieve as-is
    return {"intent": "retrieve", "standalone_query": latest,
            "clarifying_question": None,
            "rationale": "technical query, retrieving directly"}


# ════════════════════════════════════════════════════════════════════════════
# V3 CONVERSATIONAL GENERATOR  (new in v3)
# ════════════════════════════════════════════════════════════════════════════

_CONV_HISTORY_RE = re.compile(
    r"Conversation history:\s*\n(.*?)\n\nRetrieved context:", re.DOTALL
)


def _latest_operator_message(user_msg: str) -> str:
    m = _CONV_HISTORY_RE.search(user_msg)
    block = m.group(1) if m else user_msg
    operator_lines = [l[len("OPERATOR: "):].strip()
                      for l in block.split("\n") if l.strip().startswith("OPERATOR: ")]
    return operator_lines[-1] if operator_lines else ""


def _conversational_generate(req: ChatRequest) -> dict:
    user_msg   = _user_message(req)
    blocks     = _extract_chunk_blocks(user_msg)
    latest     = _latest_operator_message(user_msg)
    latest_low = latest.lower()

    if not blocks or _is_off_domain(latest_low):
        return {"abstained": True,
                "abstain_reason": "No reliable source in knowledge base for this query.",
                "claims": [], "follow_up_question": None,
                "suggested_action": "Escalate to on-call process engineer."}

    # Claims are built from whatever was ACTUALLY retrieved -- this is what
    # a real LLM grounding its answer in context does, and it guarantees
    # the claim overlaps its citation regardless of corpus composition.
    claims = _grounded_claims(blocks)
    if not claims:
        return {"abstained": True,
                "abstain_reason": "Retrieved context was too short to ground an answer.",
                "claims": [], "follow_up_question": None,
                "suggested_action": "Escalate to on-call process engineer."}

    # Topic-specific flavor: follow_up_question / suggested_action are free
    # text (not citation-checked), so they can stay keyword-routed to
    # showcase the v3 schema's extra fields without needing to match
    # whatever happened to be retrieved.
    follow_up = None
    action = None

    if "radial" in latest_low:
        action = ("Check the pad-conditioner diamond-disk wear before "
                  "adjusting carrier pressure; verify carrier-head zone "
                  "pressures are balanced per the recipe specification.")
    elif "uneven" in latest_low or "removal" in latest_low or "non-uniform" in latest_low:
        follow_up = "Is the unevenness center-to-edge or radial?"
    elif any(k in latest_low for k in ("dishing", "polish", "planariz")) and "cmp" in latest_low:
        action = "Reduce down force ~10%, inspect pad conditioner disc, verify endpoint detection is active."
    elif any(k in latest_low for k in ("secs", "gem", "hsms", "stream", "function")):
        action = "Refer to SEMI E5 (SECS-II) and E37 (HSMS) for the exact message catalog."
    elif any(k in latest_low for k in ("cleanroom", "gown", "ppe", "contamination")):
        action = "Review the cleanroom gowning SOP and confirm annual contamination-control training is current."

    return {"abstained": False, "abstain_reason": None, "claims": claims,
            "follow_up_question": follow_up, "suggested_action": action}


# ════════════════════════════════════════════════════════════════════════════
# V2 GENERATOR  (unchanged, kept for backward compat with demo.py)
# ════════════════════════════════════════════════════════════════════════════

_QUERY_RE = re.compile(r"Operator query:\s*\n(.*?)\n\nRetrieved context:", re.DOTALL)


def _operator_query(user_msg: str) -> str:
    m = _QUERY_RE.search(user_msg)
    return m.group(1) if m else user_msg


def _generate_answer(req: ChatRequest) -> dict:
    user_msg   = _user_message(req)
    blocks     = _extract_chunk_blocks(user_msg)
    query_only = _operator_query(user_msg)
    query_lower = query_only.lower()

    if not blocks or _is_off_domain(query_lower):
        return {"abstained": True,
                "abstain_reason": "No reliable source in knowledge base for this query.",
                "claims": [], "suggested_action": "Escalate to on-call process engineer."}

    claims = _grounded_claims(blocks)
    if not claims:
        return {"abstained": True,
                "abstain_reason": "Retrieved context was too short to ground an answer.",
                "claims": [], "suggested_action": "Escalate to on-call process engineer."}

    if any(k in query_lower for k in ("dishing", "cmp", "polish", "planariz")):
        action = "Reduce down force ~10%, inspect pad conditioner disc, verify endpoint detection is active."
    elif any(k in query_lower for k in ("secs", "gem", "hsms", "stream", "function")):
        action = "Refer to SEMI E5 (SECS-II) and E37 (HSMS) for the exact message catalog."
    elif any(k in query_lower for k in ("cleanroom", "gown", "ppe", "contamination")):
        action = "Review the cleanroom gowning SOP and confirm annual contamination-control training is current."
    else:
        action = "Follow the cited SOP; escalate to process engineer if unresolved."

    return {"abstained": False, "abstain_reason": None,
            "claims": claims, "suggested_action": action}


# ════════════════════════════════════════════════════════════════════════════
# Routes
# ════════════════════════════════════════════════════════════════════════════

@app.get("/health")
def health():
    return {"status": "ok", "model": MODEL_ID, "type": "mock"}


@app.get("/v1/models")
def list_models():
    return {"object": "list",
            "data": [{"id": MODEL_ID, "object": "model",
                      "owned_by": "semikong", "created": int(time.time())}]}


@app.post("/v1/chat/completions")
def chat_completions(req: ChatRequest):
    sys_prompt = _system_prompt(req)

    if _is_critic_call(req):
        content = _run_critic(req)
    elif "planning module" in sys_prompt:
        content = json.dumps(_planner_response(req))
    elif "follow_up_question" in sys_prompt:
        content = json.dumps(_conversational_generate(req))
    else:
        content = json.dumps(_generate_answer(req))

    return {
        "id": "chatcmpl-mock-001",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": req.model,
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": content},
            "finish_reason": "stop",
        }],
        "usage": {"prompt_tokens": 100, "completion_tokens": 20, "total_tokens": 120},
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", 8000)))
